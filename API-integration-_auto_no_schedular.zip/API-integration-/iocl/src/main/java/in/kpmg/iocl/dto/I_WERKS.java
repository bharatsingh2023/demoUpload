package in.kpmg.iocl.dto;

import lombok.Data;

import java.util.List;

@Data
public class I_WERKS {
    private List<I_WERKS_Item> item;
}
