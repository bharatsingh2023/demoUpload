package in.kpmg.iocl.repository;

import in.kpmg.iocl.models.YV_LU_PCK_RATE_ET_TRANSRATE;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface YV_LU_PCK_RATE_ET_TRANSRATE_REPO extends JpaRepository<YV_LU_PCK_RATE_ET_TRANSRATE,Long> {
}
