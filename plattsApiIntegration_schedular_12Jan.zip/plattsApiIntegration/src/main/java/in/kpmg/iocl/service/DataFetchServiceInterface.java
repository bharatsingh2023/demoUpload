package in.kpmg.iocl.service;

import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.plattsDailyDto.InputDto;

import java.util.List;
import java.util.Map;

public interface DataFetchServiceInterface {

    public List<ExceptionHandleClass> performPostRequest(InputDto inputObj);
    public List<ExceptionHandleClass> getTokenAndFetchMonthly(InputDto inputObj);

    public List<ExceptionHandleClass> getTokenAndFetchYearly(InputDto inputObj);

}
