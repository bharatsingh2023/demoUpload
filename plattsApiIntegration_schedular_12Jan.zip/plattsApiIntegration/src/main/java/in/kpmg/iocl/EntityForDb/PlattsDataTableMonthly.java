package in.kpmg.iocl.EntityForDb;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "ct_natural_gas_price_platts_monthly")
public class PlattsDataTableMonthly {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime created;
    private String created_by;
    private LocalDateTime modified;
    private String modified_by;
    private String record_owner;
    private LocalDateTime valid_from;
    private LocalDateTime valid_to;
    private String record_status;

    private String category;
    private String month;
    private String year;

    private String monthly_AARXS00_price;
    private Long monthly_AARXS00_currency_id;
    private Long monthly_AARXS00_uom_id;

    private String monthly_AAOVQ00_price;
    private Long monthly_AAOVQ00_currency_id;
    private Long monthly_AAOVQ00_uom_id;

    private String monthly_PCAAS00_price;
    private Long monthly_PCAAS00_currency_id;
    private Long monthly_PCAAS00_uom_id;


}
