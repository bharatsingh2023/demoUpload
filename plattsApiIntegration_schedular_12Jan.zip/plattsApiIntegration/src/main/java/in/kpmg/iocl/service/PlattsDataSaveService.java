package in.kpmg.iocl.service;

import com.fasterxml.jackson.databind.JsonMappingException;
import in.kpmg.iocl.EntityForDb.PlattsDataTable;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.plattsDailyDto.ResponsePlattsData;
import in.kpmg.iocl.entityForJsonMappin.DataItem;
import in.kpmg.iocl.entityForJsonMappin.Result;
import in.kpmg.iocl.repository.plattsDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PlattsDataSaveService {

    @Autowired
    private plattsDataRepository plattsRepo;


    public ExceptionHandleClass savePlattsDataInDb(ResponsePlattsData responsePlattsData) {
        ExceptionHandleClass exceptionResponse = new ExceptionHandleClass();
        exceptionResponse.setSuccess(true);
        exceptionResponse.setMessage("successfully saved");
        exceptionResponse.setStatus(HttpStatus.OK);
        Long $ = 202304291040055L;
        Long MMBTU = 202304121920184L;

        try {
            List<Result> results = responsePlattsData.getResults();
            Map<LocalDateTime, PlattsDataTable> dataMap = new HashMap<>();

            for (Result jsonResult : results) {
                if (jsonResult.getSymbol().equalsIgnoreCase("LMEAA00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("LMEAB00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("LMEAC00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("LMEAD00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("LMEAE00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("AAPSU00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("AAPSV00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("AAPSW00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("AAPXA00") ||
                        jsonResult.getSymbol().equalsIgnoreCase("PCAAS00")) {

                    List<DataItem> datas = jsonResult.getData();

                    for (DataItem items : datas) {
                        LocalDateTime date = LocalDateTime.parse(items.getAssessDate());
                        PlattsDataTable plattsDataTable = dataMap.get(date);


                        if (this.plattsRepo.checkValidFrom(date) > 0) {
                            // System.out.println("inside existing!!" + date);
                            PlattsDataTable ExistingData = this.plattsRepo.findByValidFrom(date);

//                          ExistingData.setCreated(LocalDateTime.now());
//                          ExistingData.setCreated_by("@ABC");
//                          ExistingData.setModified(LocalDateTime.now());
//                          ExistingData.setModified_by("@abc");
//                          ExistingData.setRecord_owner("ABC");
//                          ExistingData.setRecord_status("ACTIVE");
//                          ExistingData.setValid_to(date);


                            switch (jsonResult.getSymbol()) {
                                case "LMEAA00":
                                    ExistingData.setHalf_month__01___lmeaa00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__01___lmeaa00__currency_id($);
                                    ExistingData.setHalf_month__01___lmeaa00__uom_id(MMBTU);

                                    break;

                                case "LMEAB00":
                                    ExistingData.setHalf_month__02___lmeab00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__02___lmeab00__currency_id($);
                                    ExistingData.setHalf_month__02___lmeab00__uom_id(MMBTU);
                                    break;

                                case "LMEAC00":
                                    ExistingData.setHalf_month__01___lmeac00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__01___lmeac00__currency_id($);
                                    ExistingData.setHalf_month__01___lmeac00__uom_id(MMBTU);
                                    break;

                                case "LMEAD00":
                                    ExistingData.setHalf_month__04___lmead00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__04___lmead00__currency_id($);
                                    ExistingData.setHalf_month__04___lmead00__uom_id(MMBTU);
                                    break;

                                case "LMEAE00":
                                    ExistingData.setHalf_month__05___lmeae00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__05___lmeae00__currency_id($);
                                    ExistingData.setHalf_month__05___lmeae00__uom_id(MMBTU);
                                    break;

                                case "AAPSU00":
                                    ExistingData.setHalf_month__06___aapsu00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__06___aapsu00__currency_id($);
                                    ExistingData.setHalf_month__06___aapsu00__uom_id(MMBTU);
                                    break;

                                case "AAPSV00":
                                    ExistingData.setHalf_month__07___aapsv00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__07___aapsv00__currency_id($);
                                    ExistingData.setHalf_month__07___aapsv00__uom_id(MMBTU);
                                    break;
                                case "AAPSW00":
                                    ExistingData.setHalf_month__08___aapsw00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__08___aapsw00__currency_id($);
                                    ExistingData.setHalf_month__08___aapsw00__uom_id(MMBTU);
                                    break;
                                case "AAPXA00":
                                    ExistingData.setHalf_month__09___aapxa00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__09___aapxa00__currency_id($);
                                    ExistingData.setHalf_month__09___aapxa00__uom_id(MMBTU);
                                    break;
                                case "PCAAS00":
                                    ExistingData.setHalf_month__10___pcaas00_(String.valueOf(items.getValue()));
                                    ExistingData.setHalf_month__10___pcaas00__currency_id($);
                                    ExistingData.setHalf_month__10___pcaas00__uom_id(MMBTU);
                                    break;

                            }
                            plattsRepo.save(ExistingData);

                        } else {
                            if (plattsDataTable == null) {
                                plattsDataTable = new PlattsDataTable();
                                plattsDataTable.setValid_from(date);
                                dataMap.put(date, plattsDataTable);
                            }


                            if (jsonResult.getSymbol().equalsIgnoreCase("LMEAA00")) {
                                plattsDataTable.setHalf_month__01___lmeaa00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__01___lmeaa00__currency_id($);
                                plattsDataTable.setHalf_month__01___lmeaa00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAB00")) {
                                plattsDataTable.setHalf_month__02___lmeab00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__02___lmeab00__currency_id($);
                                plattsDataTable.setHalf_month__02___lmeab00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAC00")) {
                                plattsDataTable.setHalf_month__01___lmeac00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__01___lmeac00__currency_id($);
                                plattsDataTable.setHalf_month__01___lmeac00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAD00")) {
                                plattsDataTable.setHalf_month__04___lmead00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__04___lmead00__currency_id($);
                                plattsDataTable.setHalf_month__04___lmead00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAE00")) {
                                plattsDataTable.setHalf_month__05___lmeae00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__05___lmeae00__currency_id($);
                                plattsDataTable.setHalf_month__05___lmeae00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("AAPSU00")) {
                                plattsDataTable.setHalf_month__06___aapsu00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__06___aapsu00__currency_id($);
                                plattsDataTable.setHalf_month__06___aapsu00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("AAPSV00")) {
                                plattsDataTable.setHalf_month__07___aapsv00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__07___aapsv00__currency_id($);
                                plattsDataTable.setHalf_month__07___aapsv00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("AAPSW00")) {
                                plattsDataTable.setHalf_month__08___aapsw00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__08___aapsw00__currency_id($);
                                plattsDataTable.setHalf_month__08___aapsw00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("AAPXA00")) {
                                plattsDataTable.setHalf_month__09___aapxa00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__09___aapxa00__currency_id($);
                                plattsDataTable.setHalf_month__09___aapxa00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            } else if (jsonResult.getSymbol().equalsIgnoreCase("PCAAS00")) {
                                plattsDataTable.setHalf_month__10___pcaas00_(String.valueOf(items.getValue()));
                                plattsDataTable.setHalf_month__10___pcaas00__currency_id($);
                                plattsDataTable.setHalf_month__10___pcaas00__uom_id(MMBTU);
                                plattsDataTable.setCreated(LocalDateTime.now());
                                plattsDataTable.setCreated_by("@ABC");
                                plattsDataTable.setModified(convertToDateTime(items.getModDate()));
                                plattsDataTable.setModified_by("@abc");
                                plattsDataTable.setRecord_owner("ABC");
                                plattsDataTable.setRecord_status("ACTIVE");
                                plattsDataTable.setValid_to(date);
                            }

                        }

                    }
                }
            }

            plattsRepo.saveAll(dataMap.values());
        } catch (Exception e) {
            e.printStackTrace();
            exceptionResponse.setSuccess(false);
            exceptionResponse.setMessage("Unexpected error: " + e.getMessage());
            exceptionResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return exceptionResponse;


    }


    public LocalDateTime convertToDateTime(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        LocalDateTime dateTime = LocalDateTime.parse(date, formatter);
        return dateTime;
    }
}
