package in.kpmg.iocl.controller;

import in.kpmg.iocl.entityForJsonMappin.PlattsResponseMonthlyDto;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.plattsDailyDto.InputDto;
import in.kpmg.iocl.plattsDailyDto.ResponsePlattsData;
import in.kpmg.iocl.service.DataFetchServiceInterface;
import in.kpmg.iocl.service.GenTokenAndFetchData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class DataFetchController {
    Logger logger = LoggerFactory.getLogger(DataFetchController.class);
    @Autowired
    private GenTokenAndFetchData genTokenAndFetchData;

    @Autowired
    private DataFetchServiceInterface dataFetchServiceInterface;
    @Autowired
    private Environment environment;

    @Scheduled(cron = "0 57 8 * * *")
    @PostMapping("/fetchDataDaily")
    public ResponseEntity<?> GenerateToken() {
        logger.info("controller Executing..");
        List<ExceptionHandleClass> exceptionHandleClasses = null;
        HttpStatus status = HttpStatus.OK;

               InputDto input = new InputDto();
        input.setSymbols(Arrays.stream(Objects.requireNonNull(environment.getProperty("symbols")).split(","))
                .map(symbol -> symbol.trim().replaceAll("[\"']", ""))
                .toArray(String[]::new));
        input.setAssessDateFrom(environment.getProperty("assessDateFrom"));
        input.setM_y_Symbol(Arrays.stream(Objects.requireNonNull(environment.getProperty("m_y_Symbol")).split(","))
                .map(symbol -> symbol.trim().replaceAll("[\"']", ""))
                .toArray(String[]::new));
        input.setAssessDateTo(LocalDate.now().toString());

     //   if (input!=null) {
            try {
                // exceptionHandleClasses = genTokenAndFetchData.performPostRequest(input);
                exceptionHandleClasses = dataFetchServiceInterface.performPostRequest(input);
                List<ExceptionHandleClass> tokenAndFetchMonthly = dataFetchServiceInterface.getTokenAndFetchMonthly(input);
                List<ExceptionHandleClass> tokenAndFetchYearly = dataFetchServiceInterface.getTokenAndFetchYearly(input);

            } catch (Exception e) {
                status = HttpStatus.INTERNAL_SERVER_ERROR;
                logger.error("Error in GenerateToken(): " + e.getMessage());
            }
//        } else {
//            exceptionHandleClasses.add(new ExceptionHandleClass(false, "input field is empty", HttpStatus.BAD_REQUEST));
//        }
        return new ResponseEntity<>(exceptionHandleClasses, status);
    }


   // @Scheduled(cron = "0 18 21 * * *")

    @PostMapping("/fetchDataMonthly")
    public ResponseEntity<?> GenerateTokenAndFetchMonthy(@RequestBody InputDto input) {
        logger.info("controller monthly Executing..");
        List<ExceptionHandleClass> tokenAndFetchMonthly = null;
        HttpStatus status = HttpStatus.OK;

//        InputDto input = new InputDto();
//        input.setSymbols(Objects.requireNonNull(environment.getProperty("symbols")).split(","));
//        input.setAssessDateFrom(environment.getProperty("assessDateFrom"));
//        input.setM_y_Symbol(Objects.requireNonNull(environment.getProperty("m_y_Symbol")).split(","));
//        input.setAssessDateTo(LocalDate.now().toString());

        if (input != null) {
            try {
                 tokenAndFetchMonthly = dataFetchServiceInterface.getTokenAndFetchMonthly(input);

            } catch (Exception e) {
                status = HttpStatus.INTERNAL_SERVER_ERROR;
                logger.error("Error in GenerateToken(): " + e.getMessage());
            }
        } else {
            tokenAndFetchMonthly.add(new ExceptionHandleClass(false, "input field is empty", HttpStatus.BAD_REQUEST));
        }
        return new ResponseEntity<>(tokenAndFetchMonthly, status);
    }
//
//
//    @Scheduled(cron = "0 18 21 * * *")
//
//    @PostMapping("/fetchDataYearly")
//    public ResponseEntity<?> GenerateTokenAndFetchYearly() {
//        logger.info("controller Executing..");
//        List<ExceptionHandleClass> tokenAndFetchYearly = null;
//        HttpStatus status = HttpStatus.OK;
//
//        InputDto input = new InputDto();
//        input.setSymbols(Objects.requireNonNull(environment.getProperty("symbols")).split(","));
//        input.setAssessDateFrom(environment.getProperty("assessDateFrom"));
//        input.setM_y_Symbol(Objects.requireNonNull(environment.getProperty("m_y_Symbol")).split(","));
//        input.setAssessDateTo(LocalDate.now().toString());
//
//        if (input != null) {
//            try {
//                   tokenAndFetchYearly = dataFetchServiceInterface.getTokenAndFetchYearly(input);
//
//            } catch (Exception e) {
//                status = HttpStatus.INTERNAL_SERVER_ERROR;
//                logger.error("Error in GenerateToken(): " + e.getMessage());
//            }
//        } else {
//            tokenAndFetchYearly.add(new ExceptionHandleClass(false, "input field is empty", HttpStatus.BAD_REQUEST));
//        }
//        return new ResponseEntity<>(tokenAndFetchYearly, status);
//    }
//




//    @PostMapping("/fetchData")
//    public ResponseEntity<?> GenerateToken(@RequestBody InputDto input) {
//        logger.info("controller Executing..");
//        List<ExceptionHandleClass> exceptionHandleClasses = null;
//        HttpStatus status = HttpStatus.OK;
//
//       if(input!=null){
//           try {
//               exceptionHandleClasses = genTokenAndFetchData.performPostRequest(input);
//           } catch (Exception e) {
//               status = HttpStatus.INTERNAL_SERVER_ERROR;
//               logger.error("Error in GenerateToken(): " + e.getMessage());
//           }
//       }else{
//           exceptionHandleClasses.add(new ExceptionHandleClass(false,"input field is empty",HttpStatus.BAD_REQUEST));
//       }
//        return new ResponseEntity<>(exceptionHandleClasses, status);
//    }

/////////////////////////////////////////////cron  for every midnight////////////////////////////////////////////

//    @Scheduled(cron = "0 0 0 * * *")
//    @PostMapping("/fetchData")

//    public ResponseEntity<?> GenerateToken() {
//        logger.info("controller Executing..");
//        List<ExceptionHandleClass> exceptionHandleClasses = null;
//        HttpStatus status = HttpStatus.OK;
//
//        InputDto input = new InputDto();
//        input.setSymbols(Objects.requireNonNull(environment.getProperty("symbols")).split(","));
//        input.setAssessDateFrom(environment.getProperty("assessDateFrom"));
//        input.setM_y_Symbol(environment.getProperty("m_y_Symbol"));
//        input.setAssessDateTo(LocalDate.now().toString());
//
//
//        try {
//            exceptionHandleClasses = genTokenAndFetchData.performPostRequest(input);
//
//
//        } catch (Exception e) {
//            status = HttpStatus.INTERNAL_SERVER_ERROR;
//            logger.error("Error in GenerateToken(): " + e.getMessage());
//        }
//
//        return new ResponseEntity<>(exceptionHandleClasses, status);
//    }


}
