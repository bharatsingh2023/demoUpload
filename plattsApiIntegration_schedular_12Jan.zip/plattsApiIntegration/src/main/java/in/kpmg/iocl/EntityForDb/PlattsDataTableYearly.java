package in.kpmg.iocl.EntityForDb;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "ct_natural_gas_price_platts_yearly")
public class PlattsDataTableYearly {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime created;
    private String created_by;
    private LocalDateTime modified;
    private String modified_by;
    private String record_owner;
    private LocalDateTime valid_from;
    private LocalDateTime valid_to;
    private String record_status;

    private String category;
    private String year;

    private String yearly_AARXS00_price;
    private Long yearly_AARXS00_currency_id;
    private Long yearly_AARXS00_uom_id;

    private String yearly_AAOVQ00_price;
    private Long yearly_AAOVQ00_currency_id;
    private Long yearly_AAOVQ00_uom_id;

    private String yearly_PCAAS00_price;
    private Long yearly_PCAAS00_currency_id;
    private Long yearly_PCAAS00_uom_id;


}

