package in.kpmg.iocl.plattsDailyDto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InputDto {

    @JsonProperty("symbols")
    private String[] symbols;
    @JsonProperty("assessDateFrom")
    private String assessDateFrom;
    @JsonProperty("assessDateTo")
    private String assessDateTo;
    @JsonProperty("m_y_Symbol")
    private String[] m_y_Symbol;

}
