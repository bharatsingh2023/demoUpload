package in.kpmg.iocl.service;

import com.fasterxml.jackson.databind.JsonMappingException;
import in.kpmg.iocl.EntityForDb.PlattsDataTableYearly;
import in.kpmg.iocl.entityForJsonMappin.PlattsResponseYearly;
import in.kpmg.iocl.entityForJsonMappin.ResultYearly;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.repository.PlattsDataRepositoryYearly;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PlattsDataSaveYearly {

    @Autowired
    private PlattsDataRepositoryYearly repoYearly;


    public ExceptionHandleClass saveYearlyData(PlattsResponseYearly plattsResponseYearly) throws JsonMappingException {
        ExceptionHandleClass exceptionResponse = new ExceptionHandleClass();
        exceptionResponse.setSuccess(true);
        exceptionResponse.setMessage("successfully saved");
        exceptionResponse.setStatus(HttpStatus.OK);
        Long $ = 202304291040055L;
        Long MMBTU = 202304121920184L;

        try {
            List<ResultYearly> results = plattsResponseYearly.getResults();
            Map<String, PlattsDataTableYearly> dataMap = new HashMap<>();

            for (ResultYearly jsonResult : results) {

                String yearKey = String.valueOf(jsonResult.getYear());

                // Check if data already exists for the given year and month
                PlattsDataTableYearly plattsDataTable = this.repoYearly.findByYear(yearKey);

                if (plattsDataTable == null) {
                    plattsDataTable = new PlattsDataTableYearly();
                    plattsDataTable.setYear(String.valueOf(jsonResult.getYear()));

                    if (jsonResult.getPriceSymbol().equalsIgnoreCase("AARXS00")) {
                        plattsDataTable.setYearly_AARXS00_price(String.valueOf(jsonResult.getPrice()));
                        plattsDataTable.setYearly_AARXS00_currency_id($);
                        plattsDataTable.setYearly_AARXS00_uom_id(MMBTU);
                        plattsDataTable.setCreated(LocalDateTime.now());
                        plattsDataTable.setCreated_by("@ABC");
                        plattsDataTable.setModified(convertToDateTime(jsonResult.getModifiedDate()));
                        plattsDataTable.setModified_by("@abc");
                        plattsDataTable.setRecord_owner("ABC");
                        plattsDataTable.setRecord_status("ACTIVE");
                        plattsDataTable.setValid_from(LocalDateTime.now());
                        plattsDataTable.setValid_to(LocalDateTime.now());
                        plattsDataTable.setCategory(jsonResult.getCategoryName());

                    } else if (jsonResult.getPriceSymbol().equalsIgnoreCase("AAOVQ00")) {
                        plattsDataTable.setYearly_AAOVQ00_price(String.valueOf(jsonResult.getPrice()));
                        plattsDataTable.setYearly_AAOVQ00_currency_id($);
                        plattsDataTable.setYearly_AAOVQ00_uom_id(MMBTU);
                        plattsDataTable.setCreated(LocalDateTime.now());
                        plattsDataTable.setCreated_by("@ABC");
                        plattsDataTable.setModified(convertToDateTime(jsonResult.getModifiedDate()));
                        plattsDataTable.setModified_by("@abc");
                        plattsDataTable.setRecord_owner("ABC");
                        plattsDataTable.setRecord_status("ACTIVE");
                        plattsDataTable.setValid_from(LocalDateTime.now());
                        plattsDataTable.setValid_to(LocalDateTime.now());
                        plattsDataTable.setCategory(jsonResult.getCategoryName());

                    }else if (jsonResult.getPriceSymbol().equalsIgnoreCase("PCAAS00")) {
                        plattsDataTable.setYearly_PCAAS00_price(String.valueOf(jsonResult.getPrice()));
                        plattsDataTable.setYearly_PCAAS00_currency_id($);
                        plattsDataTable.setYearly_PCAAS00_uom_id(MMBTU);
                        plattsDataTable.setCreated(LocalDateTime.now());
                        plattsDataTable.setCreated_by("@ABC");
                        plattsDataTable.setModified(convertToDateTime(jsonResult.getModifiedDate()));
                        plattsDataTable.setModified_by("@abc");
                        plattsDataTable.setRecord_owner("ABC");
                        plattsDataTable.setRecord_status("ACTIVE");
                        plattsDataTable.setValid_from(LocalDateTime.now());
                        plattsDataTable.setValid_to(LocalDateTime.now());
                        plattsDataTable.setCategory(jsonResult.getCategoryName());

                    }

                    dataMap.put(yearKey, plattsDataTable);
                } else {
                    // Update existing data
                    if (jsonResult.getPriceSymbol().equalsIgnoreCase("AARXS00")) {
                        plattsDataTable.setYearly_AARXS00_price(String.valueOf(jsonResult.getPrice()));
                        plattsDataTable.setYearly_AARXS00_currency_id($);
                        plattsDataTable.setYearly_AARXS00_uom_id(MMBTU);
                        //  plattsDataTable.setCategory(jsonResult.getCategoryName());

                    } else if (jsonResult.getPriceSymbol().equalsIgnoreCase("AAOVQ00")) {
                        plattsDataTable.setYearly_AAOVQ00_price(String.valueOf(jsonResult.getPrice()));
                        plattsDataTable.setYearly_AAOVQ00_currency_id($);
                        plattsDataTable.setYearly_AAOVQ00_uom_id(MMBTU);
                        // plattsDataTable.setCategory(jsonResult.getCategoryName());

                    }else if (jsonResult.getPriceSymbol().equalsIgnoreCase("PCAAS00")) {
                        plattsDataTable.setYearly_PCAAS00_price(String.valueOf(jsonResult.getPrice()));
                        plattsDataTable.setYearly_PCAAS00_currency_id($);
                        plattsDataTable.setYearly_PCAAS00_uom_id(MMBTU);
                    }
                    dataMap.put(yearKey, plattsDataTable);
                }
            }

            repoYearly.saveAll(dataMap.values());

        } catch (Exception e) {
            exceptionResponse.setSuccess(false);
            exceptionResponse.setMessage("Unexpected error: " + e.getMessage());
            exceptionResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return exceptionResponse;
    }

    public LocalDateTime convertToDateTime(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        LocalDate localDate = LocalDate.parse(date, formatter);

        LocalDateTime localDateTime = LocalDateTime.of(localDate, LocalTime.MIDNIGHT);

        return localDateTime;
    }



}


//    public ExceptionHandleClass saveYearlyData(PlattsResponseYearly plattsResponseYearly) throws JsonMappingException {
//        ExceptionHandleClass exceptionResponse = new ExceptionHandleClass();
//        exceptionResponse.setSuccess(true);
//        exceptionResponse.setMessage("successfully saved");
//        exceptionResponse.setStatus(HttpStatus.OK);
//
//
//       try{
//           ObjectMapper objectMapper = new ObjectMapper();
//           List<PlattsDataTableYearly> yearlyData = new ArrayList<>();
//
//           for (ResultYearly result : plattsResponseYearly.getResults()) {
//               PlattsDataTableYearly existingData = repoYearly.findByYear(result.getYear());
//
//               if (existingData != null) {
//                   // Update the existing record with new data
//                   objectMapper.updateValue(existingData, result);
//                   repoYearly.save(existingData);
//               } else {
//                   PlattsDataTableYearly newRecord = objectMapper.convertValue(result, PlattsDataTableYearly.class);
//                   yearlyData.add(newRecord);
//               }
//           }
//           // Save all newly created records
//           repoYearly.saveAll(yearlyData);
//       }catch (JsonMappingException e){
//           exceptionResponse.setSuccess(false);
//           exceptionResponse.setMessage("Error mapping JSON: " + e.getMessage());
//           exceptionResponse.setStatus(HttpStatus.BAD_REQUEST);
//       }catch (Exception e){
//           exceptionResponse.setSuccess(false);
//           exceptionResponse.setMessage("Unexpected error: " + e.getMessage());
//           exceptionResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
//       }
//       return exceptionResponse;
//    }


