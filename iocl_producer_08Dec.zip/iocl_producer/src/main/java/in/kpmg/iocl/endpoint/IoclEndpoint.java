package in.kpmg.iocl.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import in.kpmg.iocl.api.AllCustomerRequest;
import in.kpmg.iocl.api.AllCustomerResponse;
import in.kpmg.iocl.api.CustomerSalesAreaRequest;
import in.kpmg.iocl.api.CustomerSalesAreaResponse;
import in.kpmg.iocl.serviceimpl.IoclDataServiceImpl;

@Endpoint
public class IoclEndpoint {

	private static final String NAMESPACE = "http://www.kpmg.in/iocl/api";

	@Autowired
	IoclDataServiceImpl dataService;

	@PayloadRoot(namespace = NAMESPACE, localPart = "AllCustomerRequest")
	@ResponsePayload
	public AllCustomerResponse viewCustomerByDate(@RequestPayload AllCustomerRequest getCustomer) {
		System.out.println("date range :: " + getCustomer.getStartDate() + " :: to :: " + getCustomer.getEndDate());
		return dataService.getCustomer(getCustomer.getStartDate(), getCustomer.getEndDate());
	}
	
	@PayloadRoot(namespace = NAMESPACE, localPart = "CustomerSalesAreaRequest")
	@ResponsePayload
	public CustomerSalesAreaResponse viewCustomerSalesArea(@RequestPayload CustomerSalesAreaRequest salesAreaRequest) {
		System.out.println("date range of sales :: " + salesAreaRequest.getCustomersalesAreaStartDate() + " :: to :: " + salesAreaRequest.getCustomersalesAreaEndDate());		
		CustomerSalesAreaResponse fetchCustomerSalesArea = dataService.fetchCustomerSalesArea(salesAreaRequest);
		return fetchCustomerSalesArea;
				
	}
	
	

}
