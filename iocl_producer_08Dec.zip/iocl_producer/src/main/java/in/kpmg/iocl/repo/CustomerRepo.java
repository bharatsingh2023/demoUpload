package in.kpmg.iocl.repo;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.kpmg.iocl.entity.CustomerEntity;

@Repository
public interface CustomerRepo extends JpaRepository<CustomerEntity, Long> {

	@Query(value = "select ce from CustomerEntity as ce where ce.created BETWEEN  :startdate AND :enddate")
	public List<CustomerEntity> getCustomerDataByDateRange(@Param("startdate") Date startdate,
			@Param("enddate") Date enddate);

}
