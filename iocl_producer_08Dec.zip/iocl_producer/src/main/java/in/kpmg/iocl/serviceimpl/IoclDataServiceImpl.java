package in.kpmg.iocl.serviceimpl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.kpmg.iocl.api.AllCustomerResponse;
import in.kpmg.iocl.api.AllCustomerSalesArea;
import in.kpmg.iocl.api.AllCustomers;
import in.kpmg.iocl.api.CustomerSalesAreaRequest;
import in.kpmg.iocl.api.CustomerSalesAreaResponse;
import in.kpmg.iocl.entity.CustomerEntity;
import in.kpmg.iocl.entity.CustomerSalesAreaDataEntity;
import in.kpmg.iocl.repo.CustomerRepo;
import in.kpmg.iocl.repo.CustomerSalesAreaDataRepo;

@Service
public class IoclDataServiceImpl {
	@Autowired
	CustomerRepo customerRepo;

	@Autowired
	private CustomerSalesAreaDataRepo salesAreaDataRepo;

	public AllCustomerResponse getCustomer(XMLGregorianCalendar startDate, XMLGregorianCalendar endDate) {
		AllCustomerResponse personAck = new AllCustomerResponse();
		// List<AllCustomers> targetEntityList = new ArrayList<AllCustomers>();
		AllCustomers customerData = null;
		personAck.setIsSuccess(false);
		personAck.getCustomer().add(customerData);
		System.out.println("start Date :: " + startDate + " :: end Date :: " + endDate);

		try {
			if (startDate != null && endDate != null) {
				System.out.println("start Date :: " + startDate + " :: end Date :: " + endDate);
				List<CustomerEntity> allCustomers = customerRepo.getCustomerDataByDateRange(
						startDate.toGregorianCalendar().getTime(), endDate.toGregorianCalendar().getTime());

				for (CustomerEntity customer : allCustomers) {
					customerData = new AllCustomers();
					customerData.setCode(customer.getCode());
					customerData.setName(customer.getName());
					customerData.setName2(customer.getName2());
					customerData.setName3(customer.getName3());
					customerData.setName4(customer.getName4());
					customerData.setRegNumber(customer.getReg_number());
					customerData.setShortName(customer.getShort_name());
					customerData.setAccountGroup(customer.getAccount_group_id());
					customerData.setCityStateId(customer.getCity_state_id());
					customerData.setCountryId(customer.getCountry_id());
					customerData.setPortId(customer.getPort_id());
					customerData.setIndustryId(customer.getIndustry_id());
					// customerData.setSAPCreateTime(DatatypeFactory.newInstance().newXMLGregorianCalendar());
					// customerData.setSAPModifyTime(customer.getModified());
					personAck.getCustomer().add(customerData);

				}

				if (personAck.getCustomer().size() > 0) {
					personAck.setIsSuccess(true);
					// personAck.setPerson(targetEntityList);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			personAck.setIsSuccess(false);
			personAck.getCustomer().add(customerData);
		}
		return personAck;
	}

	
	public CustomerSalesAreaResponse fetchCustomerSalesArea(CustomerSalesAreaRequest req) {
		LocalDateTime customersalesAreaStartDate = req.getCustomersalesAreaStartDate().toGregorianCalendar().toInstant()
				.atZone(ZoneId.systemDefault()).toLocalDateTime();
		LocalDateTime customersalesAreaEndDate = req.getCustomersalesAreaEndDate().toGregorianCalendar().toInstant()
				.atZone(ZoneId.systemDefault()).toLocalDateTime();

		CustomerSalesAreaResponse customerSalesAreaResponse = new CustomerSalesAreaResponse();
		customerSalesAreaResponse.setIsSuccess(false);

		List<AllCustomerSalesArea> salesFetchedList = new ArrayList<>();
		
		if (customersalesAreaStartDate != null && customersalesAreaEndDate != null) {
			try {
				List<CustomerSalesAreaDataEntity> fetchSalesData = salesAreaDataRepo
						.fetchSalesData(customersalesAreaStartDate, customersalesAreaEndDate);

				for (CustomerSalesAreaDataEntity data : fetchSalesData) {
					AllCustomerSalesArea allCustomerSalesArea = new AllCustomerSalesArea();
					allCustomerSalesArea.setCode(0);
					allCustomerSalesArea.setCurrency(data.getCurrency_id());
					allCustomerSalesArea.setDChl(null);
					allCustomerSalesArea.setSOrg(null);
					allCustomerSalesArea.setSDiv(null);
					allCustomerSalesArea.setExchangeRateType(data.getExchange_rate_type_id());
					allCustomerSalesArea.setIncoterm(data.getIncoterm_id());
					allCustomerSalesArea.setPaymentMethod(data.getPayment_method_id());
					allCustomerSalesArea.setPaymentTerm(data.getPayment_term_id());
					allCustomerSalesArea.setPlant(data.getDelivery_plant_id());
					allCustomerSalesArea.setSalesGroup(data.getSales_group_id());
					allCustomerSalesArea.setSalesOffice(data.getSales_office_id());
					allCustomerSalesArea.setSAPCreateTime(String.valueOf(data.getCreated()));
					allCustomerSalesArea.setSAPModifyTime(String.valueOf(data.getModified()));
					allCustomerSalesArea.setShippingCondition(data.getShipping_condition_id());
					salesFetchedList.add(allCustomerSalesArea);
				}

				if (salesFetchedList.size() > 0) {
					customerSalesAreaResponse.setIsSuccess(true);
					customerSalesAreaResponse.getSalesArea().addAll(salesFetchedList);

				}
			} catch (Exception e) {
				System.out.println("error in fetchCustomerSalesArea " + e.getMessage());
			}
		}

		return customerSalesAreaResponse;

	}

};