package in.kpmg.iocl.entityForJsonMappin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ResultYearly {
    @JsonProperty("year")
    private int year;
    @JsonProperty("categoryName")
    private String categoryName;
    @JsonProperty("groupName")
    private String groupName;
    @JsonProperty("priceName")
    private String priceName;
    @JsonProperty("priceSymbol")
    private String priceSymbol;
    @JsonProperty("price")
    private double price;
    @JsonProperty("unitName")
    private String unitName;
    @JsonProperty("unitId")
    private int unitId;
    @JsonProperty("currencySymbol")
    private String currencySymbol;
    @JsonProperty("currencyDescription")
    private String currencyDescription;
    @JsonProperty("priceCode")
    private int priceCode;
    @JsonProperty("priceCategoryCode")
    private int priceCategoryCode;
    @JsonProperty("priceGroupCode")
    private int priceGroupCode;
    @JsonProperty("currencyCode")
    private int currencyCode;
    @JsonProperty("sectorId")
    private int sectorId;
    @JsonProperty("sectorName")
    private String sectorName;
    @JsonProperty("deliveryRegionId")
    private int deliveryRegionId;
    @JsonProperty("deliveryRegionName")
    private String deliveryRegionName;
    @JsonProperty("commodityId")
    private int commodityId;
    @JsonProperty("commodityName")
    private String commodityName;
    @JsonProperty("modifiedDate")
    private String modifiedDate;
}

