//{
//    "status": false,
//    "message": "Internal Server Error",
//    "result": "Cannot deserialize value of type `java.util.ArrayList<in.kpmg.iocl.dto.I_TPLST_Item>` from Object value (token `JsonToken.START_OBJECT`)\n at [Source: (StringReader); line: 1, column: 118] (through reference chain: in.kpmg.iocl.dto.YV_CONTRACT_RATES_Resp[\"I_TPLST\"]->in.kpmg.iocl.dto.I_TPLST[\"item\"])",
//    "statusCode": 500
//}