package in.kpmg.iocl.repository;

import in.kpmg.iocl.EntityForDb.PlattsDataTableMonthly;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlattsDataRepositoryMonthly extends JpaRepository<PlattsDataTableMonthly,Long> {

    public PlattsDataTableMonthly findByYearAndMonth(String year, String month);

}
