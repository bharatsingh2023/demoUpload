package in.kpmg.iocl.entityForJsonMappin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class PlattsResponseMonthlyDto {

    @JsonProperty("metadata")
    private MetadataMonthly metadata;

    @JsonProperty("results")
    private List<resultsMonthly> results;


}
