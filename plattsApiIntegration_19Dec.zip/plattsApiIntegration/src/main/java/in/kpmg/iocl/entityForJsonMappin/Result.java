package in.kpmg.iocl.entityForJsonMappin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Result {
    private String symbol;
    private List<DataItem> data;
}
