-- Table: analytics_data.formulation_cost_base_import

-- DROP TABLE IF EXISTS analytics_data.formulation_cost_base_import;

CREATE TABLE IF NOT EXISTS analytics_data.formulation_cost_base_import
(
    poi_id bigint NOT NULL,
    product_code character varying COLLATE pg_catalog."default",
    blending_plant character varying COLLATE pg_catalog."default",
    import_cost numeric,
    uom character varying COLLATE pg_catalog."default",
    currency character varying COLLATE pg_catalog."default",
    valid_from date,
    valid_to date,
    created_on date,
    CONSTRAINT formulation_cost_base_import_pkey PRIMARY KEY (poi_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS analytics_data.formulation_cost_base_import
    OWNER to postgres;

CREATE SEQUENCE IF NOT EXISTS analytics_data.formulation_cost_base_import_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 999999
    CACHE 1
    OWNED BY formulation_cost_base_import.poi_id;

ALTER SEQUENCE analytics_data.formulation_cost_base_import_seq
    OWNER TO postgres;