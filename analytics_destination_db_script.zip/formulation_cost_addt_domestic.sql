-- Table: analytics_data.formulation_cost_addt_domestic

-- DROP TABLE IF EXISTS analytics_data.formulation_cost_addt_domestic;

CREATE TABLE IF NOT EXISTS analytics_data.formulation_cost_addt_domestic
(
    domestic_cost_id bigint NOT NULL,
    product_code character varying COLLATE pg_catalog."default",
    blending_plant character varying COLLATE pg_catalog."default",
    cost numeric,
    uom character varying COLLATE pg_catalog."default",
    currency character varying COLLATE pg_catalog."default",
    valid_from date,
    valid_to date,
    created_on date,
    CONSTRAINT formulation_cost_addt_domestic_pkey PRIMARY KEY (domestic_cost_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS analytics_data.formulation_cost_addt_domestic
    OWNER to postgres;

CREATE SEQUENCE IF NOT EXISTS analytics_data.formulation_cost_addt_domestic_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 999999
    CACHE 1
    OWNED BY formulation_cost_addt_domestic.domestic_cost_id;

ALTER SEQUENCE analytics_data.formulation_cost_addt_domestic_seq
    OWNER TO postgres;