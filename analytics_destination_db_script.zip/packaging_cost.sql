-- Table: analytics_data.packaging_input_cost

-- DROP TABLE IF EXISTS analytics_data.packaging_input_cost;

CREATE TABLE IF NOT EXISTS analytics_data.packaging_input_cost
(
    pkg_cost_id bigint NOT NULL,
    packaging_material character varying COLLATE pg_catalog."default",
    blending_plant character varying COLLATE pg_catalog."default",
    pkg_cost numeric,
    uom character varying COLLATE pg_catalog."default",
    currency character varying COLLATE pg_catalog."default",
    valid_from date,
    valid_to date,
    created_on date,
    CONSTRAINT packaging_input_cost_pkey PRIMARY KEY (pkg_cost_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS analytics_data.packaging_input_cost
    OWNER to postgres;

CREATE SEQUENCE IF NOT EXISTS analytics_data.packaging_cost_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 999999
    CACHE 1
    OWNED BY packaging_input_cost.pkg_cost_id;

ALTER SEQUENCE analytics_data.packaging_cost_seq
    OWNER TO postgres;