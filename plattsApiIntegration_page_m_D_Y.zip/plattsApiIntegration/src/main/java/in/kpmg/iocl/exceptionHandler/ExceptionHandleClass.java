package in.kpmg.iocl.exceptionHandler;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.http.HttpStatus;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ExceptionHandleClass {

    private boolean success;
    private String message;
    private HttpStatus status;



}
