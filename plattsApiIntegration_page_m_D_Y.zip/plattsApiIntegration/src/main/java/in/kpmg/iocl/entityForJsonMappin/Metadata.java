package in.kpmg.iocl.entityForJsonMappin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Metadata {
    private int count;
    private int pageSize;
    private int page;
    private int totalPages;
    private String queryTime;


}
