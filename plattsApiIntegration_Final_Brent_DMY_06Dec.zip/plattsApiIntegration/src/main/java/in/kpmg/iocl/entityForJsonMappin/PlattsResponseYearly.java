package in.kpmg.iocl.entityForJsonMappin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class PlattsResponseYearly {
    @JsonProperty("metadata")
    private MetadataYearly metadata;

    @JsonProperty("results")
    private List<ResultYearly> results;

}
