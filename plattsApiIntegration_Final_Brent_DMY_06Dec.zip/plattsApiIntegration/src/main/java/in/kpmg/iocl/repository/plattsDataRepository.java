package in.kpmg.iocl.repository;

import in.kpmg.iocl.EntityForDb.PlattsDataTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.time.LocalDateTime;

@Repository
public interface plattsDataRepository  extends JpaRepository<PlattsDataTable,BigInteger> {

    @Query(value = "Select count(plt.valid_from) from  ct_natural_gas_price_platts plt where plt.valid_from=:DATE",nativeQuery = true)
    public int checkValidFrom(@Param("DATE") LocalDateTime date);

    @Query(value = "Select * from  ct_natural_gas_price_platts plt where plt.valid_from=:DATE",nativeQuery = true)
    PlattsDataTable findByValidFrom(@Param("DATE") LocalDateTime date);
}
