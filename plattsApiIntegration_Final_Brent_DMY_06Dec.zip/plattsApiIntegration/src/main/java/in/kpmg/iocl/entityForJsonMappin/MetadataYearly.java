package in.kpmg.iocl.entityForJsonMappin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MetadataYearly {
    @JsonProperty("count")
    private int count;
    @JsonProperty("page")
    private int page;
    @JsonProperty("pageSize")
    private int pageSize;
    @JsonProperty("queryTime")
    private int queryTime;

}
