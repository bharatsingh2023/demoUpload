package in.kpmg.iocl.clientService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

import in.kpmg.iocl.allclassfromwsdl.AllCustomerRequest;
import in.kpmg.iocl.allclassfromwsdl.AllCustomerResponse;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaPartnerRequest;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaPartnerResponse;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaRequest;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaResponse;

@Service
public class Client {

	@Autowired
	private Jaxb2Marshaller marshaller;

	private WebServiceTemplate template;
	@Autowired
	Environment environment;

	public CustomerSalesAreaResponse getSalesAreaData(CustomerSalesAreaRequest request) {
		
		template = new WebServiceTemplate(marshaller);
		
		CustomerSalesAreaResponse salesAreaResponse = (CustomerSalesAreaResponse) template
				.marshalSendAndReceive(environment.getProperty("url_producer"), request);
		return salesAreaResponse;
	}
	
	public AllCustomerResponse getAllCustomerData(AllCustomerRequest request) {
		
		template = new WebServiceTemplate(marshaller);
		
		AllCustomerResponse allCustomerResponse = (AllCustomerResponse) template
				.marshalSendAndReceive(environment.getProperty("url_producer"), request);
		return allCustomerResponse;
	}
	
	
public CustomerSalesAreaPartnerResponse getSalesPartnerData(CustomerSalesAreaPartnerRequest request) {
		
		template = new WebServiceTemplate(marshaller);
		
		CustomerSalesAreaPartnerResponse salesAreaPartnerResponse = (CustomerSalesAreaPartnerResponse) template
				.marshalSendAndReceive(environment.getProperty("url_producer"), request);
		return salesAreaPartnerResponse;
	}

}
