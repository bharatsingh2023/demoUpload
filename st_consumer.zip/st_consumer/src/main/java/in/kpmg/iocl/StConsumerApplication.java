//package in.kpmg.iocl;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class StConsumerApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(StConsumerApplication.class, args);
//	}
//
//}

package in.kpmg.iocl;

import java.time.LocalDate;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.kpmg.iocl.clientService.Client;
import in.kpmg.iocl.allclassfromwsdl.AllCustomerRequest;
import in.kpmg.iocl.allclassfromwsdl.AllCustomerResponse;
import in.kpmg.iocl.allclassfromwsdl.AllCustomerSalesArea;
import in.kpmg.iocl.allclassfromwsdl.AllCustomerSalesAreaPartner;
import in.kpmg.iocl.allclassfromwsdl.AllCustomers;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaPartnerRequest;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaPartnerResponse;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaRequest;
import in.kpmg.iocl.allclassfromwsdl.CustomerSalesAreaResponse;

@SpringBootApplication
public class StConsumerApplication {

	public static void main(String[] args) throws DatatypeConfigurationException {
		ConfigurableApplicationContext context = SpringApplication.run(StConsumerApplication.class, args);
		invokeService(context);
	}

	public static void invokeService(ConfigurableApplicationContext context) throws DatatypeConfigurationException {
		Client client = context.getBean(Client.class);

		CustomerSalesAreaRequest request = new CustomerSalesAreaRequest();
		request.setCustomersalesAreaStartDate("18-05-2023 00:00:00.000");
		request.setCustomersalesAreaEndDate("19-05-2023 00:00:00.000");

		AllCustomerRequest allCustomerRequest = new AllCustomerRequest();
		allCustomerRequest.setStartDate("18-05-2023 00:00:00.000");
		allCustomerRequest.setEndDate("19-05-2023 00:00:00.000");

		CustomerSalesAreaPartnerRequest AreaPartnerRequest = new CustomerSalesAreaPartnerRequest();
		AreaPartnerRequest.setCustomersalesAreaPartnerCRorMDStartDate(
				DatatypeFactory.newInstance().newXMLGregorianCalendar(LocalDate.of(2023, 5, 18).toString()));
		AreaPartnerRequest.setCustomersalesAreaPartnerCRorMDEndDate(
				DatatypeFactory.newInstance().newXMLGregorianCalendar(LocalDate.of(2023, 5, 19).toString()));

		CustomerSalesAreaResponse response = client.getSalesAreaData(request);
		AllCustomerResponse allCustomerDataRes = client.getAllCustomerData(allCustomerRequest);
		    CustomerSalesAreaPartnerResponse salesPartnerData = client.getSalesPartnerData(AreaPartnerRequest);

		List<AllCustomerSalesArea> salesArea = response.getSalesArea();
		for (AllCustomerSalesArea sData : salesArea) {
			System.out.println("Response sales Area: " + sData);

		}
		List<AllCustomers> allCustomer = allCustomerDataRes.getCustomer();
		for (AllCustomers cdata : allCustomer) {
			System.out.println("Response AllCustomer: " + cdata);

		}
		List<AllCustomerSalesAreaPartner> partners = salesPartnerData.getPartners();
		for (AllCustomerSalesAreaPartner pdata : partners) {
			System.out.println("Response sales partner : " + pdata);

		}

		context.close();
	}
}
