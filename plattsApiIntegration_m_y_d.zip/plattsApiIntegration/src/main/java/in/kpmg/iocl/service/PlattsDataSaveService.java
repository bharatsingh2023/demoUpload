package in.kpmg.iocl.service;

import com.fasterxml.jackson.databind.JsonMappingException;
import in.kpmg.iocl.EntityForDb.PlattsDataTable;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.plattsDailyDto.ResponsePlattsData;
import in.kpmg.iocl.entityForJsonMappin.DataItem;
import in.kpmg.iocl.entityForJsonMappin.Result;
import in.kpmg.iocl.repository.plattsDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PlattsDataSaveService {

    @Autowired
    private plattsDataRepository plattsRepo;


    public ExceptionHandleClass savePlattsDataInDb(ResponsePlattsData responsePlattsData) {
        ExceptionHandleClass exceptionResponse = new ExceptionHandleClass();
        exceptionResponse.setSuccess(true);
        exceptionResponse.setMessage("successfully saved");
        exceptionResponse.setStatus(HttpStatus.OK);

        try{
          List<Result> results = responsePlattsData.getResults();
          Map<String, PlattsDataTable> dataMap = new HashMap<>();

          for (Result jsonResult : results) {
              if (jsonResult.getSymbol().equalsIgnoreCase("LMEAA00") ||
                      jsonResult.getSymbol().equalsIgnoreCase("LMEAB00") ||
                      jsonResult.getSymbol().equalsIgnoreCase("LMEAC00") ||
                      jsonResult.getSymbol().equalsIgnoreCase("LMEAD00") ||
                      jsonResult.getSymbol().equalsIgnoreCase("LMEAE00") ||
                      jsonResult.getSymbol().equalsIgnoreCase("AARXS00") ||
                      jsonResult.getSymbol().equalsIgnoreCase("AWIMM01") ||
                      jsonResult.getSymbol().equalsIgnoreCase("AWIMM02") ||
                      jsonResult.getSymbol().equalsIgnoreCase("AWIMM03") ||
                      jsonResult.getSymbol().equalsIgnoreCase("AWIMY01") ||
                      jsonResult.getSymbol().equalsIgnoreCase("AWIMY02") ||
                      jsonResult.getSymbol().equalsIgnoreCase("AWIMY03")) {

                  List<DataItem> datas = jsonResult.getData();

                  for (DataItem items : datas) {
                      String date = items.getAssessDate();
                      PlattsDataTable plattsDataTable = dataMap.get(date);


                      if (this.plattsRepo.checkDate(items.getAssessDate()) > 0) {
                          // System.out.println("inside existing!!" + date);
                          PlattsDataTable ExistingData = this.plattsRepo.findByDate(date);


                          switch (jsonResult.getSymbol()) {
                              case "LMEAA00":
                                  ExistingData.setHalf_month__01___lmeaa00_(items.getValue());
                                  ExistingData.setHalf_month__01___lmeaa00__currency_id("$");
                                  ExistingData.setHalf_month__01___lmeaa00__uom_id("MMBTU");
                                  break;

                              case "LMEAB00":
                                  ExistingData.setHalf_month__02___lmeab00_(items.getValue());
                                  ExistingData.setHalf_month__02___lmeab00__currency_id("$");
                                  ExistingData.setHalf_month__02___lmeab00__uom_id("MMBTU");
                                  break;

                              case "LMEAC00":
                                  ExistingData.setHalf_month__03___lmeac00_(items.getValue());
                                  ExistingData.setHalf_month__03___lmeac00__currency_id("$");
                                  ExistingData.setHalf_month__03___lmeac00__uom_id("MMBTU");
                                  break;

                              case "LMEAD00":
                                  ExistingData.setHalf_month__04___lmead00_(items.getValue());
                                  ExistingData.setHalf_month__04___lmead00__currency_id("$");
                                  ExistingData.setHalf_month__04___lmead00__uom_id("MMBTU");
                                  break;

                              case "LMEAE00":
                                  ExistingData.setHalf_month__05___lmeae00_(items.getValue());
                                  ExistingData.setHalf_month__05___lmeae00__currency_id("$");
                                  ExistingData.setHalf_month__05___lmeae00__uom_id("MMBTU");
                                  break;

                              case "AARXS00":
                                  ExistingData.setM_1__aarxs00_(items.getValue());
                                  ExistingData.setM_1__aarxs00__currency_id("$");
                                  ExistingData.setM_1__aarxs00__uom_id("MMBTU");
                                  break;

                              case "AWIMM01":
                                  ExistingData.setM_2__awimm01_(items.getValue());
                                  ExistingData.setM_2__awimm01__currency_id("$");
                                  ExistingData.setM_2__awimm01__uom_id("MMBTU");
                                  break;

                              case "AWIMM02":
                                  ExistingData.setM_3__awimm02_(items.getValue());
                                  ExistingData.setM_3__awimm02__currency_id("$");
                                  ExistingData.setM_3__awimm02__uom_id("MMBTU");
                                  break;

                              case "AWIMM03":
                                  ExistingData.setM_4__awimm03_(items.getValue());
                                  ExistingData.setM_4__awimm03__currency_id("$");
                                  ExistingData.setM_4__awimm03__uom_id("MMBTU");
                                  break;

                              case "AWIMY01":
                                  ExistingData.setY_1__awimy01_(items.getValue());
                                  ExistingData.setY_1__awimy01__currency_id("$");
                                  ExistingData.setY_1__awimy01__uom_id("MMBTU");
                                  break;

                              case "AWIMY02":
                                  ExistingData.setY_2__awimy02_(items.getValue());
                                  ExistingData.setY_2__awimy02__currency_id("$");
                                  ExistingData.setY_2__awimy02__uom_id("MMBTU");
                                  break;

                              case "AWIMY03":
                                  ExistingData.setY_3__awimy03_(items.getValue());
                                  ExistingData.setY_3__awimy03__currency_id("$");
                                  ExistingData.setY_3__awimy03__uom_id("MMBTU");
                                  break;


                          }
                          plattsRepo.save(ExistingData);

                      } else {
                          if (plattsDataTable == null) {
                              plattsDataTable = new PlattsDataTable();
                              plattsDataTable.setDate(date);
                              dataMap.put(date, plattsDataTable);
                          }


                          if (jsonResult.getSymbol().equalsIgnoreCase("LMEAA00")) {
                              plattsDataTable.setHalf_month__01___lmeaa00_(items.getValue());
                              plattsDataTable.setHalf_month__01___lmeaa00__currency_id("$");
                              plattsDataTable.setHalf_month__01___lmeaa00__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAB00")) {
                              plattsDataTable.setHalf_month__02___lmeab00_(items.getValue());
                              plattsDataTable.setHalf_month__02___lmeab00__currency_id("$");
                              plattsDataTable.setHalf_month__02___lmeab00__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAC00")) {
                              plattsDataTable.setHalf_month__03___lmeac00_(items.getValue());
                              plattsDataTable.setHalf_month__03___lmeac00__currency_id("$");
                              plattsDataTable.setHalf_month__03___lmeac00__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAD00")) {
                              plattsDataTable.setHalf_month__04___lmead00_(items.getValue());
                              plattsDataTable.setHalf_month__04___lmead00__currency_id("$");
                              plattsDataTable.setHalf_month__04___lmead00__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("LMEAE00")) {
                              plattsDataTable.setHalf_month__05___lmeae00_(items.getValue());
                              plattsDataTable.setHalf_month__05___lmeae00__currency_id("$");
                              plattsDataTable.setHalf_month__05___lmeae00__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("AARXS00")) {
                              plattsDataTable.setM_1__aarxs00_(items.getValue());
                              plattsDataTable.setM_1__aarxs00__currency_id("$");
                              plattsDataTable.setM_1__aarxs00__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("AWIMM01")) {
                              plattsDataTable.setM_2__awimm01_(items.getValue());
                              plattsDataTable.setM_2__awimm01__currency_id("$");
                              plattsDataTable.setM_2__awimm01__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("AWIMM02")) {
                              plattsDataTable.setM_3__awimm02_(items.getValue());
                              plattsDataTable.setM_3__awimm02__currency_id("$");
                              plattsDataTable.setM_3__awimm02__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("AWIMM03")) {
                              plattsDataTable.setM_4__awimm03_(items.getValue());
                              plattsDataTable.setM_4__awimm03__currency_id("$");
                              plattsDataTable.setM_4__awimm03__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("AWIMY01")) {
                              plattsDataTable.setY_1__awimy01_(items.getValue());
                              plattsDataTable.setY_1__awimy01__currency_id("$");
                              plattsDataTable.setY_1__awimy01__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("AWIMY02")) {
                              plattsDataTable.setY_2__awimy02_(items.getValue());
                              plattsDataTable.setY_2__awimy02__currency_id("$");
                              plattsDataTable.setY_2__awimy02__uom_id("MMBTU");
                          } else if (jsonResult.getSymbol().equalsIgnoreCase("AWIMY03")) {
                              plattsDataTable.setY_3__awimy03_(items.getValue());
                              plattsDataTable.setY_3__awimy03__currency_id("$");
                              plattsDataTable.setY_3__awimy03__uom_id("MMBTU");
                          }
                      }

                  }
              }
          }

          plattsRepo.saveAll(dataMap.values());
      } catch (Exception e){
          exceptionResponse.setSuccess(false);
          exceptionResponse.setMessage("Unexpected error: " + e.getMessage());
          exceptionResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
      }
        return exceptionResponse;



    }


}
