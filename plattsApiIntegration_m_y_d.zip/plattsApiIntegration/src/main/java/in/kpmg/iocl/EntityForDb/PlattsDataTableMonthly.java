package in.kpmg.iocl.EntityForDb;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "ct_natural_gas_price_platts_monthly")
public class PlattsDataTableMonthly {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int year;
    private int month;
    private String categoryName;
    private String groupName;
    private String priceName;
    private String priceSymbol;
    private double price;
    private String unitName;
    private int unitId;
    private String currencySymbol;
    private String currencyDescription;
    private int priceCode;
    private int priceCategoryCode;
    private int priceGroupCode;
    private int currencyCode;
    private int sectorId;
    private String sectorName;
    private int deliveryRegionId;
    private String deliveryRegionName;
    private int commodityId;
    private String commodityName;
    private String modifiedDate;

}
