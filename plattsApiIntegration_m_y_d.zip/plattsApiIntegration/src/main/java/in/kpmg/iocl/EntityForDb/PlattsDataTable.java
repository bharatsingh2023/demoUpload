package in.kpmg.iocl.EntityForDb;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ct_natural_gas_price_platts")
public class PlattsDataTable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String created;
    private String created_by;
    private String modified;
    private String modified_by;
    private String record_owner;
    private String valid_from;
    private String valid_to;
    private String record_status;


    private String date;
    private double half_month__02___lmeab00_;
    private String half_month__02___lmeab00__currency_id;
    private String half_month__02___lmeab00__uom_id;

    private double half_month__01___lmeaa00_;
    private String half_month__01___lmeaa00__currency_id;
    private String half_month__01___lmeaa00__uom_id;

    private double half_month__03___lmeac00_;
    private String half_month__03___lmeac00__currency_id;
    private String half_month__03___lmeac00__uom_id;

    private double half_month__04___lmead00_;
    private String half_month__04___lmead00__currency_id;
    private String half_month__04___lmead00__uom_id;

    private double half_month__05___lmeae00_;
    private String half_month__05___lmeae00__currency_id;
    private String half_month__05___lmeae00__uom_id;

    private double m_1__aarxs00_;
    private String m_1__aarxs00__currency_id;
    private String m_1__aarxs00__uom_id;

    private double m_2__awimm01_;
    private String m_2__awimm01__currency_id;
    private String m_2__awimm01__uom_id;

    private double m_3__awimm02_;
    private String m_3__awimm02__currency_id;
    private String m_3__awimm02__uom_id;

    private double m_4__awimm03_;
    private String m_4__awimm03__currency_id;
    private String m_4__awimm03__uom_id;

    private double y_1__awimy01_;
    private String y_1__awimy01__currency_id;
    private String y_1__awimy01__uom_id;

    private double y_2__awimy02_;
    private String y_2__awimy02__currency_id;
    private String y_2__awimy02__uom_id;

    private double y_3__awimy03_;
    private String y_3__awimy03__currency_id;
    private String y_3__awimy03__uom_id;


}
