package in.kpmg.iocl.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import in.kpmg.iocl.entityForJsonMappin.PlattsResponseYearly;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.plattsDailyDto.InputDto;
import in.kpmg.iocl.plattsDailyDto.ResponsePlattsData;
import in.kpmg.iocl.entityForJsonMappin.PlattsResponseMonthlyDto;
import lombok.SneakyThrows;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GenTokenAndFetchData {
    @Autowired
    private PlattsDataSaveService plattsDataSaveService;
    @Autowired
    private PlattsDataSaveMonthly plattsDataSaveMonthly;
    @Autowired
    private PlattsDataSaveYearly plattsDataSaveYearly;
    Logger logger = LoggerFactory.getLogger(GenTokenAndFetchData.class);

    private static final String URL = "https://api.platts.com/auth/api";
    private static final String APP_KEY = "ILWhWevStDzHEtjhjpsE";
    private static final String USERNAME = "BDNatGas@indianoil.in";
    private static final String PASSWORD = "Bdgas@789";


    public List<ExceptionHandleClass> performPostRequest(InputDto inputObj) {
        logger.info("performPostRequest Executing..");

        List<ExceptionHandleClass> exceptionHandleClasses=null;

        try {
            URL url = new URL(URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty("appkey", APP_KEY);
            connection.setDoOutput(true);
            String requestBody = "username=" + USERNAME + "&password=" + PASSWORD;

            byte[] postData = requestBody.getBytes(StandardCharsets.UTF_8);
            int postDataLength = postData.length;
            connection.setRequestProperty("Content-Length", String.valueOf(postDataLength));
            connection.getOutputStream().write(postData);

            int responseCode = connection.getResponseCode();
            System.out.println("POST Response Code: " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                String responseData = response.toString();
                JSONObject jsonResponse = new JSONObject(responseData);
                String accessToken = jsonResponse.getString("access_token");

                logger.info("Access Token: " + accessToken);
                try{
                     exceptionHandleClasses = fetchDataDaily(inputObj, accessToken);
                }catch (Exception e){
                    logger.error(e.getMessage());
                }

            } else {
                logger.error("POST request failed. with responseCode :" + responseCode);
            }

            connection.disconnect();
        } catch (IOException e) {
            logger.error("error in performPostRequest of plattsApi " + e.getMessage());
        }
        return exceptionHandleClasses;

    }


    @SneakyThrows
    public List<ExceptionHandleClass> fetchDataDaily(InputDto inputObj, String token) throws UnsupportedEncodingException {

        List<ExceptionHandleClass> listofException = new ArrayList<>();

        ExceptionHandleClass responseStatus=null;

        System.out.println("input.. :" + inputObj);

        String baseUrl = "https://api.platts.com/market-data/v3/value/history/symbol";
        String[] symbols = inputObj.getSymbols();
        String assessDateFrom = inputObj.getAssessDateFrom();
        String assessDateTo = inputObj.getAssessDateTo();
        //String modDate=inputObj.getModDate();
        String qry = null;
        List<String> encodedSymbols = new ArrayList<>();
        for (String symbol : symbols) {
            encodedSymbols.add("\"" + symbol + "\"");
        }
        if (!encodedSymbols.isEmpty()) {
            //  String symbolFilter = "symbol IN (" + String.join(",", encodedSymbols) + ")";
            qry = "symbol IN (" + String.join(",", encodedSymbols) + ")";
        }
        String assessDateFilter = "assessDate>\"" + assessDateFrom + "\" AND assessDate<\"" + assessDateTo + "\"";

        if (assessDateFrom != null && assessDateTo != null && !encodedSymbols.isEmpty()) {
            qry = String.join(" AND ", qry, assessDateFilter);
        }


        String encodedQry = URLEncoder.encode(qry, "UTF-8").replaceAll("\\+", "%20");
        String pageSize = "PageSize=10000";
        String generated_url = baseUrl + "?Filter=" + encodedQry + "&" + pageSize;

        logger.info("Constructed URL: " + generated_url);

        String accessToken = "Bearer " + token;
        try {
            String url = generated_url;
            URL apiUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();

            connection.setRequestMethod("GET");
            connection.setRequestProperty("appkey", "ILWhWevStDzHEtjhjpsE");
            connection.setRequestProperty("authorization", accessToken);


            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }

                in.close();

                ObjectMapper objectMapper = new ObjectMapper();
                ResponsePlattsData responsePlattsData = objectMapper.readValue(response.toString(), ResponsePlattsData.class);
                // logger.info("responsePlattsData" + responsePlattsData);

                try {//data going to save
                    ExceptionHandleClass exceptionHandleDaily = plattsDataSaveService.savePlattsDataInDb(responsePlattsData);
                    if (exceptionHandleDaily.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved dailyData", HttpStatus.OK);
                        listofException.add(responseStatus);
                    } else {

                        responseStatus = new ExceptionHandleClass(false, "failed to save dailyData", HttpStatus.INTERNAL_SERVER_ERROR);
                        listofException.add(responseStatus);

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("Error while saving data!! " + e.getLocalizedMessage());
                    responseStatus = new ExceptionHandleClass(false, "failed to save dailyData", HttpStatus.INTERNAL_SERVER_ERROR);

                }
                try {
                    Map<String, ExceptionHandleClass> tokenAndFetchMonthlyAndYearly = getTokenAndFetchMonthlyAndYearly(inputObj);
                    listofException.add(tokenAndFetchMonthlyAndYearly.get("yearlyData"));
                    listofException.add(tokenAndFetchMonthlyAndYearly.get("monthlyData"));
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("error while executing getTokenAndFetchMonthlyAndYearly " + e.getMessage());
                }

            } else {
                logger.error("GET request failed with response code: " + responseCode);
            }

        } catch (IOException e) {
            logger.error("Error: " + e.getMessage());

        }
        return listofException;
    }


    //////////////////////////////////////Bearer Token Gen for Monthly And Yearly////////////////////////////////
    public Map<String, ExceptionHandleClass> getTokenAndFetchMonthlyAndYearly(InputDto inputObj) {
        Map<String, ExceptionHandleClass> exceptionHashMap = new HashMap<>();

        ExceptionHandleClass responseStatus = null;
        logger.info("getToken for monthly and yearly Executing...");
        ResponsePlattsData responsePlattsData = null;

        try {
            URL url = new URL(URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty("appkey", "IrNNMkRASrrNKfdZsMjb");
            connection.setDoOutput(true);
            String requestBody = "username=" + USERNAME + "&password=" + PASSWORD;

            byte[] postData = requestBody.getBytes(StandardCharsets.UTF_8);
            int postDataLength = postData.length;
            connection.setRequestProperty("Content-Length", String.valueOf(postDataLength));
            connection.getOutputStream().write(postData);

            int responseCode = connection.getResponseCode();
            System.out.println("POST Response Code: " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                String responseData = response.toString();
                JSONObject jsonResponse = new JSONObject(responseData);
                String accessToken = jsonResponse.getString("access_token");

                logger.info("Access Token Short/long: " + accessToken);
                try {
                    ExceptionHandleClass monthlyDataExc = getMonthlyData(inputObj, accessToken);
                    if (monthlyDataExc.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved monthlyData", HttpStatus.OK);
                        exceptionHashMap.put("monthlyData", responseStatus);
                    } else {

                        responseStatus = new ExceptionHandleClass(false, "failed to save monthlyData", HttpStatus.INTERNAL_SERVER_ERROR);
                        exceptionHashMap.put("monthlyData", responseStatus);
                    }

                } catch (Exception e) {
                    logger.error(e.getMessage());
                }

                try {
                    ExceptionHandleClass yearlyData = getYearlyData(inputObj, accessToken);
                    if (yearlyData.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved yearlyData", HttpStatus.OK);
                        exceptionHashMap.put("yearlyData", responseStatus);
                    } else {

                        responseStatus = new ExceptionHandleClass(false, "failed to save yearlyData", HttpStatus.INTERNAL_SERVER_ERROR);
                        exceptionHashMap.put("yearlyData", responseStatus);
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }


            } else {
                logger.error("POST request failed for short/long time data with responseCode :" + responseCode);
            }

            connection.disconnect();
        } catch (IOException e) {
            logger.error("error in performPostRequest of plattsApi short/long " + e.getMessage());
        }
        return exceptionHashMap;
    }


    public ExceptionHandleClass getMonthlyData(InputDto inputDto, String accessToken) throws UnsupportedEncodingException {

        ExceptionHandleClass responseStatus = null;
        System.out.println("Executing" + inputDto.getM_y_Symbol());
        String baseUrl = "https://api.platts.com/energy-price-forecast/v1/prices-short-term";
        // String apiKey = "IrNNMkRASrrNKfdZsMjb";
        String input = inputDto.getM_y_Symbol();
        String qry = null;
        if (!input.isEmpty()) {

            qry = "priceSymbol: \"" + input + "\"";
        }

        String encodedQry = URLEncoder.encode(qry, "UTF-8").replaceAll("\\+", "%20");

        String pageSize = "PageSize=1000";
        String generated_url = baseUrl + "?Filter=" + encodedQry + "&" + pageSize;

        logger.info("Constructed URL: " + generated_url);

        String token = "Bearer " + accessToken;
        try {
            String url = generated_url;
            URL apiUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();

            connection.setRequestMethod("GET");
            connection.setRequestProperty("appkey", "IrNNMkRASrrNKfdZsMjb");
            connection.setRequestProperty("authorization", token);


            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }

                in.close();

                ObjectMapper objectMapper = new ObjectMapper();
                PlattsResponseMonthlyDto plattsResponseMonthly = objectMapper.readValue(response.toString(), PlattsResponseMonthlyDto.class);
                logger.info("responsePlattsData" + plattsResponseMonthly);

                try {//data going to save
                    ExceptionHandleClass ExcphandleClass = plattsDataSaveMonthly.saveMonthlyData(plattsResponseMonthly);
                    if (ExcphandleClass.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved", HttpStatus.OK);
                    } else {
                        responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("Error while saving monthlydata!! " + e.getLocalizedMessage());
                    responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                }

            } else {
                logger.error("GET request failed while fetching Monthly data, with response code: " + responseCode);
                responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } catch (IOException e) {
            logger.error("Error: " + e.getMessage());
            responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

        }
        return responseStatus;
    }


    public ExceptionHandleClass getYearlyData(InputDto inputDto, String accessToken) throws UnsupportedEncodingException {


        ExceptionHandleClass responseStatus = null;
        System.out.println("inside getYearlyData with symbol: " + inputDto.getM_y_Symbol());
        String baseUrl = "https://api.platts.com/energy-price-forecast/v1/prices-long-term";
        String input = inputDto.getM_y_Symbol();
        String qry = null;
        if (!input.isEmpty()) {
            // qry = "symbol IN (" + String.join(",", input) + ")";
            qry = "priceSymbol: \"" + input + "\"";
        }

        String encodedQry = URLEncoder.encode(qry, "UTF-8").replaceAll("\\+", "%20");

        // String generated_url = baseUrl + "?Filter=" + encodedQry;
        String pageSize = "PageSize=1000";
        String generated_url = baseUrl + "?Filter=" + encodedQry + "&" + pageSize;

        logger.info("Constructed URL: " + generated_url);

        String token = "Bearer " + accessToken;
        try {
            String url = generated_url;
            URL apiUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();

            connection.setRequestMethod("GET");
            connection.setRequestProperty("appkey", "IrNNMkRASrrNKfdZsMjb");
            connection.setRequestProperty("authorization", token);


            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }

                in.close();

                ObjectMapper objectMapper = new ObjectMapper();
                PlattsResponseYearly plattsResponseYearly = objectMapper.readValue(response.toString(), PlattsResponseYearly.class);
                logger.info("responsePlattsData" + plattsResponseYearly);

                try {
                    ExceptionHandleClass exceptionHandle = plattsDataSaveYearly.saveYearlyData(plattsResponseYearly);
                    if (exceptionHandle.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved", HttpStatus.OK);
                    } else {
                        responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("Error while saving data!! " + e.getLocalizedMessage());
                    responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                }


            } else {
                logger.error("GET request failed while fetching Yearly data ,with response code : " + responseCode);
                responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

            }

        } catch (IOException e) {
            logger.error("Error: " + e.getMessage());
            responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

        }
        return responseStatus;
    }


}
