package in.kpmg.iocl.repository;

import in.kpmg.iocl.EntityForDb.PlattsDataTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;

@Repository
public interface plattsDataRepository  extends JpaRepository<PlattsDataTable,BigInteger> {

    @Query(value = "Select count(plt.date) from  ct_natural_gas_price_platts plt where plt.date=:DATE",nativeQuery = true)
    public int checkDate(@Param("DATE") String date);

    PlattsDataTable findByDate(String date);
}
