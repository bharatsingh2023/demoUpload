package in.kpmg.iocl.service;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.kpmg.iocl.EntityForDb.PlattsDataTableMonthly;
import in.kpmg.iocl.EntityForDb.PlattsDataTableYearly;
import in.kpmg.iocl.entityForJsonMappin.PlattsResponseYearly;
import in.kpmg.iocl.entityForJsonMappin.ResultYearly;
import in.kpmg.iocl.entityForJsonMappin.resultsMonthly;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.repository.PlattsDataRepositoryYearly;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PlattsDataSaveYearly {

    @Autowired
    private PlattsDataRepositoryYearly repoYearly;

    public ExceptionHandleClass saveYearlyData(PlattsResponseYearly plattsResponseYearly) throws JsonMappingException {
        ExceptionHandleClass exceptionResponse = new ExceptionHandleClass();
        exceptionResponse.setSuccess(true);
        exceptionResponse.setMessage("successfully saved");
        exceptionResponse.setStatus(HttpStatus.OK);


       try{
           ObjectMapper objectMapper = new ObjectMapper();
           List<PlattsDataTableYearly> yearlyData = new ArrayList<>();

           for (ResultYearly result : plattsResponseYearly.getResults()) {
               PlattsDataTableYearly existingData = repoYearly.findByYear(result.getYear());

               if (existingData != null) {
                   // Update the existing record with new data
                   objectMapper.updateValue(existingData, result);
                   repoYearly.save(existingData);
               } else {
                   PlattsDataTableYearly newRecord = objectMapper.convertValue(result, PlattsDataTableYearly.class);
                   yearlyData.add(newRecord);
               }
           }
           // Save all newly created records
           repoYearly.saveAll(yearlyData);
       }catch (JsonMappingException e){
           exceptionResponse.setSuccess(false);
           exceptionResponse.setMessage("Error mapping JSON: " + e.getMessage());
           exceptionResponse.setStatus(HttpStatus.BAD_REQUEST);
       }catch (Exception e){
           exceptionResponse.setSuccess(false);
           exceptionResponse.setMessage("Unexpected error: " + e.getMessage());
           exceptionResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
       }
       return exceptionResponse;
    }
}

