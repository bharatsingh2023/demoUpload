package in.kpmg.iocl.controller;

import in.kpmg.iocl.entityForJsonMappin.PlattsResponseMonthlyDto;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.plattsDailyDto.InputDto;
import in.kpmg.iocl.plattsDailyDto.ResponsePlattsData;
import in.kpmg.iocl.service.GenTokenAndFetchData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class DataFetchController {
    Logger logger = LoggerFactory.getLogger(DataFetchController.class);
    @Autowired
    private GenTokenAndFetchData genTokenAndFetchData;
    @Autowired
    private Environment environment;


    @PostMapping("/fetchData")
    public ResponseEntity<?> GenerateToken(@RequestBody InputDto input) {
        logger.info("controller Executing..");
        List<ExceptionHandleClass> exceptionHandleClasses = null;
        HttpStatus status = HttpStatus.OK;

        try {
            exceptionHandleClasses = genTokenAndFetchData.performPostRequest(input);
        } catch (Exception e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            logger.error("Error in GenerateToken(): " + e.getMessage());
        }
        return new ResponseEntity<>(exceptionHandleClasses, status);
    }

/////////////////////////////////////////////cron  for every midnight////////////////////////////////////////////

//    @Scheduled(cron = "0 0 0 * * *")
//    @PostMapping("/fetchData")
//    public ResponseEntity<?> GenerateToken() {
//        logger.info("controller Executing..");
//        List<ExceptionHandleClass> exceptionHandleClasses = null;
//        HttpStatus status = HttpStatus.OK;
//
//        InputDto input = new InputDto();
//        input.setSymbols(Objects.requireNonNull(environment.getProperty("symbols")).split(","));
//        input.setAssessDateFrom(environment.getProperty("assessDateFrom"));
//        input.setM_y_Symbol(environment.getProperty("m_y_Symbol"));
//        // input.setAssessDateTo(environment.getProperty("assessDateTo"));
//        input.setAssessDateTo(LocalDate.now().toString());
//
//
//        try {
//            exceptionHandleClasses = genTokenAndFetchData.performPostRequest(input);
//
//
//        } catch (Exception e) {
//            status = HttpStatus.INTERNAL_SERVER_ERROR;
//            logger.error("Error in GenerateToken(): " + e.getMessage());
//        }
//
//        return new ResponseEntity<>(exceptionHandleClasses, status);
//    }


}
