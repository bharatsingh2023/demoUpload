package in.kpmg.iocl.plattsDailyDto;

import in.kpmg.iocl.entityForJsonMappin.Metadata;
import in.kpmg.iocl.entityForJsonMappin.Result;
import lombok.*;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ResponsePlattsData {
    private Metadata metadata;
    private List<Result> results;

}
