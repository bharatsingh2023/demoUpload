package in.kpmg.iocl.entityForJsonMappin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DataItem {
    private String bate;
    private double value;
    private String assessDate;
    private String isCorrected;
    private String modDate;

}
