package in.kpmg.iocl.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.kpmg.iocl.entityForJsonMappin.PlattsResponseYearly;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.plattsDailyDto.InputDto;
import in.kpmg.iocl.plattsDailyDto.ResponsePlattsData;
import in.kpmg.iocl.entityForJsonMappin.PlattsResponseMonthlyDto;
import lombok.SneakyThrows;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GenTokenAndFetchData {
    @Autowired
    private PlattsDataSaveService plattsDataSaveService;
    @Autowired
    private PlattsDataSaveMonthly plattsDataSaveMonthly;
    @Autowired
    private PlattsDataSaveYearly plattsDataSaveYearly;
    Logger logger = LoggerFactory.getLogger(GenTokenAndFetchData.class);

    private static final String URL = "https://api.platts.com/auth/api";
    private static final String APP_KEY = "ILWhWevStDzHEtjhjpsE";
    private static final String USERNAME = "BDNatGas@indianoil.in";
    private static final String PASSWORD = "Bdgas@789";


    public List<ExceptionHandleClass> performPostRequest(InputDto inputObj) {
        logger.info("performPostRequest Executing..");

        List<ExceptionHandleClass> exceptionHandleClasses = new ArrayList<>();

        try {
            CloseableHttpClient closeableHttpClient = getCloseableHttpClient();
            if (closeableHttpClient != null) {
                HttpPost httpPost = new HttpPost(URL);
                httpPost.addHeader("appkey", APP_KEY);

                // Assuming 'inputObj' contains username and password for the request
                StringEntity requestBody = new StringEntity("username=" + USERNAME + "&password=" + PASSWORD);
                requestBody.setContentType("application/x-www-form-urlencoded");
                httpPost.setEntity(requestBody);

                HttpResponse response = closeableHttpClient.execute(httpPost);
                int responseCode = response.getStatusLine().getStatusCode();
                System.out.println("POST Response Code: " + responseCode);

                if (responseCode == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                    String inputLine;
                    StringBuilder responseContent = new StringBuilder();

                    while ((inputLine = reader.readLine()) != null) {
                        responseContent.append(inputLine);
                    }
                    reader.close();

                    String responseData = responseContent.toString();
                    JSONObject jsonResponse = new JSONObject(responseData);
                    String accessToken = jsonResponse.getString("access_token");

                    logger.info("Access Token: " + accessToken);
                    try {
                         exceptionHandleClasses = fetchDataDaily(inputObj, accessToken);

                    }catch (Exception e){
                        logger.error("error while fetching Daily data : " +e.getMessage());
                    }

                } else {
                    logger.error("POST request failed with responseCode: " + responseCode);
                }
            }
        } catch (IOException | JSONException e) {
            logger.error("Error in performPostRequest of plattsApi: " + e.getMessage());
        }

        return exceptionHandleClasses;
    }



    @SneakyThrows
    public List<ExceptionHandleClass> fetchDataDaily(InputDto inputObj, String token) throws UnsupportedEncodingException {

        List<ExceptionHandleClass> listofException = new ArrayList<>();

        ExceptionHandleClass responseStatus = null;

        System.out.println("input.. :" + inputObj);

        String baseUrl = "https://api.platts.com/market-data/v3/value/history/symbol";
        String[] symbols = inputObj.getSymbols();
        String assessDateFrom = inputObj.getAssessDateFrom();
        String assessDateTo = inputObj.getAssessDateTo();
        //String modDate=inputObj.getModDate();
        String qry = null;
        List<String> encodedSymbols = new ArrayList<>();
        for (String symbol : symbols) {
            encodedSymbols.add("\"" + symbol + "\"");
        }
        if (!encodedSymbols.isEmpty()) {
            //  String symbolFilter = "symbol IN (" + String.join(",", encodedSymbols) + ")";
            qry = "symbol IN (" + String.join(",", encodedSymbols) + ")";
        }
        String assessDateFilter = "assessDate>\"" + assessDateFrom + "\" AND assessDate<\"" + assessDateTo + "\"";

        if (assessDateFrom != null && assessDateTo != null && !encodedSymbols.isEmpty()) {
            qry = String.join(" AND ", qry, assessDateFilter);
        }


        String encodedQry = URLEncoder.encode(qry, "UTF-8").replaceAll("\\+", "%20");
        String pageSize = "PageSize=10000";
        int Page = 1;
        boolean morePages = true;
        while (morePages) {
            String generated_url = baseUrl + "?Filter=" + encodedQry + "&" + pageSize + "&Page=" + Page;

            logger.info("Constructed URL: " + generated_url);

            String accessToken = "Bearer " + token;
            try {
//
                HttpGet httpGet = new HttpGet(generated_url);
                httpGet.addHeader("appkey", "ILWhWevStDzHEtjhjpsE");
                httpGet.addHeader("authorization", accessToken);

                CloseableHttpClient httpClient = getCloseableHttpClient();
                CloseableHttpResponse responseGet = httpClient.execute(httpGet);

                int responseCode = responseGet.getStatusLine().getStatusCode();

                if (responseCode == 200) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(responseGet.getEntity().getContent()));
                    StringBuilder response = new StringBuilder();
                    String inputLine;

                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }

                    in.close();

                    ObjectMapper objectMapper = new ObjectMapper();
                    ResponsePlattsData responsePlattsData = objectMapper.readValue(response.toString(), ResponsePlattsData.class);
                    // logger.info("responsePlattsData" + responsePlattsData);

                    try {
                        ExceptionHandleClass exceptionHandleDaily = plattsDataSaveService.savePlattsDataInDb(responsePlattsData);
                        if (exceptionHandleDaily.getStatus() == HttpStatus.OK) {
                            responseStatus = new ExceptionHandleClass(true, "successfully saved dailyData of page  " + Page, HttpStatus.OK);
                            listofException.add(responseStatus);

                            int currentPage = responsePlattsData.getMetadata().getPage();
                            int totalPages = responsePlattsData.getMetadata().getTotalPages();

                            if (currentPage < totalPages) {
                                Page++; // Move to the next page
                            } else {
                                morePages = false; // No more pages available
                            }


                        } else {

                            responseStatus = new ExceptionHandleClass(false, "failed to save dailyData", HttpStatus.INTERNAL_SERVER_ERROR);
                            listofException.add(responseStatus);
                            morePages = false;

                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error("Error while saving data!! " + e.getLocalizedMessage());
                        responseStatus = new ExceptionHandleClass(false, "failed to save dailyData", HttpStatus.INTERNAL_SERVER_ERROR);
                        morePages = false;
                    }
                } else {
                    logger.error("GET request failed with response code: " + responseCode);
                }

            } catch (IOException e) {
                logger.error("Error: " + e.getMessage());
            }

        }

        try {
            Map<String, ExceptionHandleClass> tokenAndFetchMonthlyAndYearly = getTokenAndFetchMonthlyAndYearly(inputObj);
            listofException.add(tokenAndFetchMonthlyAndYearly.get("yearlyData"));
            listofException.add(tokenAndFetchMonthlyAndYearly.get("monthlyData"));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("error while executing getTokenAndFetchMonthlyAndYearly " + e.getMessage());
        }
        return listofException;
    }


    //////////////////////////////////////Bearer Token Gen for Monthly And Yearly////////////////////////////////
    public Map<String, ExceptionHandleClass> getTokenAndFetchMonthlyAndYearly(InputDto inputObj) {
        Map<String, ExceptionHandleClass> exceptionHashMap = new HashMap<>();

        ExceptionHandleClass responseStatus = null;
        logger.info("getToken for monthly and yearly Executing...");
        ResponsePlattsData responsePlattsData = null;

        try {
            URL url = new URL(URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty("appkey", "IrNNMkRASrrNKfdZsMjb");
            connection.setDoOutput(true);
            String requestBody = "username=" + USERNAME + "&password=" + PASSWORD;

            byte[] postData = requestBody.getBytes(StandardCharsets.UTF_8);
            int postDataLength = postData.length;
            connection.setRequestProperty("Content-Length", String.valueOf(postDataLength));
            connection.getOutputStream().write(postData);

            int responseCode = connection.getResponseCode();
            System.out.println("POST Response Code: " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                String responseData = response.toString();
                JSONObject jsonResponse = new JSONObject(responseData);
                String accessToken = jsonResponse.getString("access_token");

                logger.info("Access Token Short/long: " + accessToken);
                try {
                    ExceptionHandleClass monthlyDataExc = getMonthlyData(inputObj, accessToken);
                    if (monthlyDataExc.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved monthlyData", HttpStatus.OK);
                        exceptionHashMap.put("monthlyData", responseStatus);
                    } else {

                        responseStatus = new ExceptionHandleClass(false, "failed to save monthlyData", HttpStatus.INTERNAL_SERVER_ERROR);
                        exceptionHashMap.put("monthlyData", responseStatus);
                    }

                } catch (Exception e) {
                    logger.error(e.getMessage());
                }

                try {
                    ExceptionHandleClass yearlyData = getYearlyData(inputObj, accessToken);
                    if (yearlyData.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved yearlyData", HttpStatus.OK);
                        exceptionHashMap.put("yearlyData", responseStatus);
                    } else {

                        responseStatus = new ExceptionHandleClass(false, "failed to save yearlyData", HttpStatus.INTERNAL_SERVER_ERROR);
                        exceptionHashMap.put("yearlyData", responseStatus);
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }


            } else {
                logger.error("POST request failed for short/long time data with responseCode :" + responseCode);
            }

            connection.disconnect();
        } catch (IOException e) {
            logger.error("error in performPostRequest of plattsApi short/long " + e.getMessage());
        }
        return exceptionHashMap;
    }


    public ExceptionHandleClass getMonthlyData(InputDto inputDto, String accessToken) throws UnsupportedEncodingException {

        ExceptionHandleClass responseStatus = null;
        System.out.println("Executing" + inputDto.getM_y_Symbol());
        String baseUrl = "https://api.platts.com/energy-price-forecast/v1/prices-short-term";
        // String apiKey = "IrNNMkRASrrNKfdZsMjb";
        String input = inputDto.getM_y_Symbol();
        String qry = null;
        if (!input.isEmpty()) {

            qry = "priceSymbol: \"" + input + "\"";
        }

        String encodedQry = URLEncoder.encode(qry, "UTF-8").replaceAll("\\+", "%20");

        String pageSize = "PageSize=1000";
        String generated_url = baseUrl + "?Filter=" + encodedQry + "&" + pageSize;

        logger.info("Constructed URL: " + generated_url);

        String token = "Bearer " + accessToken;
        try {
            String url = generated_url;
            URL apiUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();

            connection.setRequestMethod("GET");
            connection.setRequestProperty("appkey", "IrNNMkRASrrNKfdZsMjb");
            connection.setRequestProperty("authorization", token);


            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }

                in.close();

                ObjectMapper objectMapper = new ObjectMapper();
                PlattsResponseMonthlyDto plattsResponseMonthly = objectMapper.readValue(response.toString(), PlattsResponseMonthlyDto.class);
                logger.info("responsePlattsData" + plattsResponseMonthly);

                try {//data going to save
                    ExceptionHandleClass ExcphandleClass = plattsDataSaveMonthly.saveMonthlyData(plattsResponseMonthly);
                    if (ExcphandleClass.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved", HttpStatus.OK);
                    } else {
                        responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("Error while saving monthlydata!! " + e.getLocalizedMessage());
                    responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                }

            } else {
                logger.error("GET request failed while fetching Monthly data, with response code: " + responseCode);
                responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } catch (IOException e) {
            logger.error("Error: " + e.getMessage());
            responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

        }
        return responseStatus;
    }


    public ExceptionHandleClass getYearlyData(InputDto inputDto, String accessToken) throws UnsupportedEncodingException {


        ExceptionHandleClass responseStatus = null;
        System.out.println("inside getYearlyData with symbol: " + inputDto.getM_y_Symbol());
        String baseUrl = "https://api.platts.com/energy-price-forecast/v1/prices-long-term";
        String input = inputDto.getM_y_Symbol();
        String qry = null;
        if (!input.isEmpty()) {
            // qry = "symbol IN (" + String.join(",", input) + ")";
            qry = "priceSymbol: \"" + input + "\"";
        }

        String encodedQry = URLEncoder.encode(qry, "UTF-8").replaceAll("\\+", "%20");

        // String generated_url = baseUrl + "?Filter=" + encodedQry;
        String pageSize = "PageSize=1000";
        String generated_url = baseUrl + "?Filter=" + encodedQry + "&" + pageSize;

        logger.info("Constructed URL: " + generated_url);

        String token = "Bearer " + accessToken;
        try {
            String url = generated_url;
            URL apiUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();

            connection.setRequestMethod("GET");
            connection.setRequestProperty("appkey", "IrNNMkRASrrNKfdZsMjb");
            connection.setRequestProperty("authorization", token);


            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }

                in.close();

                ObjectMapper objectMapper = new ObjectMapper();
                PlattsResponseYearly plattsResponseYearly = objectMapper.readValue(response.toString(), PlattsResponseYearly.class);
                logger.info("responsePlattsData" + plattsResponseYearly);

                try {
                    ExceptionHandleClass exceptionHandle = plattsDataSaveYearly.saveYearlyData(plattsResponseYearly);
                    if (exceptionHandle.getStatus() == HttpStatus.OK) {
                        responseStatus = new ExceptionHandleClass(true, "successfully saved", HttpStatus.OK);
                    } else {
                        responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("Error while saving data!! " + e.getLocalizedMessage());
                    responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

                }


            } else {
                logger.error("GET request failed while fetching Yearly data ,with response code : " + responseCode);
                responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

            }

        } catch (IOException e) {
            logger.error("Error: " + e.getMessage());
            responseStatus = new ExceptionHandleClass(false, "failed to save", HttpStatus.INTERNAL_SERVER_ERROR);

        }
        return responseStatus;
    }


    public static CloseableHttpClient getCloseableHttpClient() {
        CloseableHttpClient httpClient = null;
        try {
            httpClient = HttpClients.custom().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
                        public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
                            return true;
                        }
                    }).build()).build();
        } catch (KeyManagementException e) {
            System.out.println("KeyManagementException in creating http client instance" + e);
        } catch (NoSuchAlgorithmException e) {
            System.out.println("NoSuchAlgorithmException in creating http client instance" + e);
        } catch (KeyStoreException e) {
            System.out.println("KeyStoreException in creating http client instance" + e);
        }
        return httpClient;
    }
//    public ApiResponse2 YV_LU_PCK_RATE(PaymentDto dto) {
//        String url = "https://coisebizuat.ds.indianoil.in:7000/uat/RESTAdapter/RFC/MKHO/YV_LU_PCK_RATE",
//                userName = "b2buser", password = "iocl1234", request = "";
//        Map<Integer, String> responseMap = new HashMap<>();
//
//        try {
//
//            StringEntity inputString = null;
////            String jsonInputString1 = "{\r\n" + "    \"I_FROM_DATE\": \"2022-01-05\",\r\n"
////                    + "    \"I_TO_DATE\": \"2022-01-30\",\r\n" + "    \"I_WERKS\": {\r\n" + "      \"item\": {\r\n"
////                    + "        \"WERKS\": \"4136\"\r\n" + "      }\r\n" + "    }\r\n" + "  }";
//
//
//
//            String jsonInputString = "{\n" +
//                    "    \"I_FROM_DATE\" :" + dto.getI_FROM_DATE() + "," +
//                    "    \"I_TO_DATE\" :" + dto.getI_TO_DATE() + "," +
//                    "    \"I_WERKS\":\n" +
//                    "    {\n" +
//                    "        \"item\":\n" +
//                    "        {\n" +
//                    "            \"WERKS\" :" + dto.getWERKS() +
//                    "        }\n" +
//                    "\n"+
//                    "    }\n" +
//                    "\n"+
//                    "}";
//            try {
//
//                inputString = new StringEntity(jsonInputString);
//                System.out.println(inputString);
//            } catch (UnsupportedEncodingException e1) {
//                e1.printStackTrace();
//            }
//
//            HttpPost postRequest = new HttpPost(url);
//
//            String auth = userName + ":" + password;
//            byte[] encodedAuth = org.apache.commons.codec.binary.Base64.encodeBase64(auth.getBytes(StandardCharsets.ISO_8859_1));
//            System.out.println("Encoded String = " + new String(encodedAuth));
//            String authHeader = "Basic " + new String(encodedAuth);
//            System.out.println("Auth String =" + authHeader);
//            postRequest.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
//
//            inputString.setContentType("application/json");
//
//            postRequest.setEntity(inputString);
//
//            CloseableHttpClient closeableHttpClient = getCloseableHttpClient();
//
//            HttpResponse response1 = closeableHttpClient.execute(postRequest);
//
//            int statusCode = response1.getStatusLine().getStatusCode();
//
//            String json = EntityUtils.toString(response1.getEntity());
//            ObjectMapper mapper = new ObjectMapper();
//            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
//            mapper.configure(DeserializationFeature.ACCEPT_FLOAT_AS_INT,false);
////            mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
////            mapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
//            YV_LU_PCK_Rate_Response response = mapper.readValue(json, YV_LU_PCK_Rate_Response.class);
//            System.out.println("Test" + json);



        }
