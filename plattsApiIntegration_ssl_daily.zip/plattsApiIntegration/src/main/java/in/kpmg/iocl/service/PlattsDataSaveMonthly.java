package in.kpmg.iocl.service;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.kpmg.iocl.EntityForDb.PlattsDataTableMonthly;
import in.kpmg.iocl.entityForJsonMappin.PlattsResponseMonthlyDto;
import in.kpmg.iocl.entityForJsonMappin.resultsMonthly;
import in.kpmg.iocl.exceptionHandler.ExceptionHandleClass;
import in.kpmg.iocl.repository.PlattsDataRepositoryMonthly;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PlattsDataSaveMonthly {

    @Autowired
    private PlattsDataRepositoryMonthly repoMonthly;

    public ExceptionHandleClass saveMonthlyData(PlattsResponseMonthlyDto plattsResponseMonthly) throws JsonMappingException {

        ExceptionHandleClass exceptionResponse = new ExceptionHandleClass();
        exceptionResponse.setSuccess(true);
        exceptionResponse.setMessage("successfully saved");
        exceptionResponse.setStatus(HttpStatus.OK);


        try{
        ObjectMapper objectMapper = new ObjectMapper();
        List<PlattsDataTableMonthly> monthlyData = new ArrayList<>();

        for (resultsMonthly result : plattsResponseMonthly.getResults()) {
            PlattsDataTableMonthly existingData = repoMonthly.findByYearAndMonth(result.getYear(), result.getMonth());

            if (existingData != null) {
                // Update the existing record with new data
                objectMapper.updateValue(existingData, result);
                repoMonthly.save(existingData);
            } else {
                PlattsDataTableMonthly newRecord = objectMapper.convertValue(result, PlattsDataTableMonthly.class);
                monthlyData.add(newRecord);
            }
        }
        // Save all newly created records
        repoMonthly.saveAll(monthlyData);
    }catch (JsonMappingException e){
        exceptionResponse.setSuccess(false);
        exceptionResponse.setMessage("Error mapping JSON: " + e.getMessage());
        exceptionResponse.setStatus(HttpStatus.BAD_REQUEST);
    }catch (Exception e){
        exceptionResponse.setSuccess(false);
        exceptionResponse.setMessage("Unexpected error: " + e.getMessage());
        exceptionResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    }
        return exceptionResponse;
    }


}
