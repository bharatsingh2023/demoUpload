package in.kpmg.iocl.repository;

import in.kpmg.iocl.EntityForDb.PlattsDataTableYearly;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlattsDataRepositoryYearly extends JpaRepository<PlattsDataTableYearly,Long> {

    public PlattsDataTableYearly findByYear(int year);
}
