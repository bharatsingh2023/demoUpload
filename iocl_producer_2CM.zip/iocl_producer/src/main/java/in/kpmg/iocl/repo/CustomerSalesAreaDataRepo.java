package in.kpmg.iocl.repo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.kpmg.iocl.entity.CustomerSalesAreaDataEntity;

public interface CustomerSalesAreaDataRepo extends JpaRepository<CustomerSalesAreaDataEntity, Long> {

	  @Query(value = "SELECT * FROM iocl.tb_customer_sales_area_data csd WHERE csd.created BETWEEN :from AND :to", nativeQuery = true)
	    List<CustomerSalesAreaDataEntity> fetchSalesData(
	        @Param("from") LocalDateTime startDate,
	        @Param("to") LocalDateTime endDate
	    );


}
