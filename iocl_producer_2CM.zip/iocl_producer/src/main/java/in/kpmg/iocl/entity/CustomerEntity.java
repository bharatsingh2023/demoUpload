package in.kpmg.iocl.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "tb_customer", schema = "iocl")
public class CustomerEntity {
	@Id
	private long customer_id;
	@Temporal(TemporalType.TIMESTAMP)
	private Date created;
	private String created_by;
	@Temporal(TemporalType.TIMESTAMP)
	private Date modified;
	private String modified_by;
	private String code;
	private String name;
	private String name2;
	private String name3;
	private String name4;
	private String reg_number;
	private String short_name;
	private String status;
	private long account_group_id;
	private long city_state_id;
	private long contact_id;
	private long country_id;
	private long industry_id;
	private long port_id;
	private long customer_type_id;
	private String name_with_code;
	private String record_status;
	private String uuid;
	private String date_archived;
	private String column25;
	private String column26;
	private String column27;
	private String column28;
	private String column29;
	private String column11;

	public long getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getModified() {
		return modified;
	}

	public void setModified(Date modified) {
		this.modified = modified;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName2() {
		return name2;
	}

	public void setName2(String name2) {
		this.name2 = name2;
	}

	public String getName3() {
		return name3;
	}

	public void setName3(String name3) {
		this.name3 = name3;
	}

	public String getName4() {
		return name4;
	}

	public void setName4(String name4) {
		this.name4 = name4;
	}

	public String getReg_number() {
		return reg_number;
	}

	public void setReg_number(String reg_number) {
		this.reg_number = reg_number;
	}

	public String getShort_name() {
		return short_name;
	}

	public void setShort_name(String short_name) {
		this.short_name = short_name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getAccount_group_id() {
		return account_group_id;
	}

	public void setAccount_group_id(long account_group_id) {
		this.account_group_id = account_group_id;
	}

	public long getCity_state_id() {
		return city_state_id;
	}

	public void setCity_state_id(long city_state_id) {
		this.city_state_id = city_state_id;
	}

	public long getContact_id() {
		return contact_id;
	}

	public void setContact_id(long contact_id) {
		this.contact_id = contact_id;
	}

	public long getCountry_id() {
		return country_id;
	}

	public void setCountry_id(long country_id) {
		this.country_id = country_id;
	}

	public long getIndustry_id() {
		return industry_id;
	}

	public void setIndustry_id(long industry_id) {
		this.industry_id = industry_id;
	}

	public long getPort_id() {
		return port_id;
	}

	public void setPort_id(long port_id) {
		this.port_id = port_id;
	}

	public long getCustomer_type_id() {
		return customer_type_id;
	}

	public void setCustomer_type_id(long customer_type_id) {
		this.customer_type_id = customer_type_id;
	}

	public String getName_with_code() {
		return name_with_code;
	}

	public void setName_with_code(String name_with_code) {
		this.name_with_code = name_with_code;
	}

	public String getRecord_status() {
		return record_status;
	}

	public void setRecord_status(String record_status) {
		this.record_status = record_status;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getDate_archived() {
		return date_archived;
	}

	public void setDate_archived(String date_archived) {
		this.date_archived = date_archived;
	}

	public String getColumn25() {
		return column25;
	}

	public void setColumn25(String column25) {
		this.column25 = column25;
	}

	public String getColumn26() {
		return column26;
	}

	public void setColumn26(String column26) {
		this.column26 = column26;
	}

	public String getColumn27() {
		return column27;
	}

	public void setColumn27(String column27) {
		this.column27 = column27;
	}

	public String getColumn28() {
		return column28;
	}

	public void setColumn28(String column28) {
		this.column28 = column28;
	}

	public String getColumn29() {
		return column29;
	}

	public void setColumn29(String column29) {
		this.column29 = column29;
	}

	public String getColumn11() {
		return column11;
	}

	public void setColumn11(String column11) {
		this.column11 = column11;
	}

}
