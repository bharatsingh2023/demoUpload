package in.kpmg.iocl.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_customer_sales_area_data")
public class CustomerSalesAreaDataEntity {

	@Id
	private Long customer_sales_area_data_id;
	private LocalDateTime created;
	private String created_by;
	private LocalDateTime modified;
	private String modified_by;
	private String order_block;
	private String status;
	private Long currency_id;
	private Long customer_id;
	private Long delivery_plant_id;
	private Long exchange_rate_type_id;
	private Long incoterm_id;
	private Long payment_method_id;
	private Long payment_term_id;
	private Long  sales_area_id;
	private Long sales_group_id;
	private Long sales_office_id;
	private Long shipping_condition_id;
	private String record_status;
	private String date_archived;
	private String column21;
	private String column22;
	private String column23;
	private String column24;
	public Long getCustomer_sales_area_data_id() {
		return customer_sales_area_data_id;
	}
	public void setCustomer_sales_area_data_id(Long customer_sales_area_data_id) {
		this.customer_sales_area_data_id = customer_sales_area_data_id;
	}
	public LocalDateTime getCreated() {
		return created;
	}
	public void setCreated(LocalDateTime created) {
		this.created = created;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public LocalDateTime getModified() {
		return modified;
	}
	public void setModified(LocalDateTime modified) {
		this.modified = modified;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public String getOrder_block() {
		return order_block;
	}
	public void setOrder_block(String order_block) {
		this.order_block = order_block;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getCurrency_id() {
		return currency_id;
	}
	public void setCurrency_id(Long currency_id) {
		this.currency_id = currency_id;
	}
	public Long getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(Long customer_id) {
		this.customer_id = customer_id;
	}
	public Long getDelivery_plant_id() {
		return delivery_plant_id;
	}
	public void setDelivery_plant_id(Long delivery_plant_id) {
		this.delivery_plant_id = delivery_plant_id;
	}
	public Long getExchange_rate_type_id() {
		return exchange_rate_type_id;
	}
	public void setExchange_rate_type_id(Long exchange_rate_type_id) {
		this.exchange_rate_type_id = exchange_rate_type_id;
	}
	public Long getIncoterm_id() {
		return incoterm_id;
	}
	public void setIncoterm_id(Long incoterm_id) {
		this.incoterm_id = incoterm_id;
	}
	public Long getPayment_method_id() {
		return payment_method_id;
	}
	public void setPayment_method_id(Long payment_method_id) {
		this.payment_method_id = payment_method_id;
	}
	public Long getPayment_term_id() {
		return payment_term_id;
	}
	public void setPayment_term_id(Long payment_term_id) {
		this.payment_term_id = payment_term_id;
	}
	public Long getSales_area_id() {
		return sales_area_id;
	}
	public void setSales_area_id(Long sales_area_id) {
		this.sales_area_id = sales_area_id;
	}
	public Long getSales_group_id() {
		return sales_group_id;
	}
	public void setSales_group_id(Long sales_group_id) {
		this.sales_group_id = sales_group_id;
	}
	public Long getSales_office_id() {
		return sales_office_id;
	}
	public void setSales_office_id(Long sales_office_id) {
		this.sales_office_id = sales_office_id;
	}
	public Long getShipping_condition_id() {
		return shipping_condition_id;
	}
	public void setShipping_condition_id(Long shipping_condition_id) {
		this.shipping_condition_id = shipping_condition_id;
	}
	public String getRecord_status() {
		return record_status;
	}
	public void setRecord_status(String record_status) {
		this.record_status = record_status;
	}
	public String getDate_archived() {
		return date_archived;
	}
	public void setDate_archived(String date_archived) {
		this.date_archived = date_archived;
	}
	public String getColumn21() {
		return column21;
	}
	public void setColumn21(String column21) {
		this.column21 = column21;
	}
	public String getColumn22() {
		return column22;
	}
	public void setColumn22(String column22) {
		this.column22 = column22;
	}
	public String getColumn23() {
		return column23;
	}
	public void setColumn23(String column23) {
		this.column23 = column23;
	}
	public String getColumn24() {
		return column24;
	}
	public void setColumn24(String column24) {
		this.column24 = column24;
	}
	@Override
	public String toString() {
		return "CustomerSalesAreaDataEntity [customer_sales_area_data_id=" + customer_sales_area_data_id + ", created="
				+ created + ", created_by=" + created_by + ", modified=" + modified + ", modified_by=" + modified_by
				+ ", order_block=" + order_block + ", status=" + status + ", currency_id=" + currency_id
				+ ", customer_id=" + customer_id + ", delivery_plant_id=" + delivery_plant_id
				+ ", exchange_rate_type_id=" + exchange_rate_type_id + ", incoterm_id=" + incoterm_id
				+ ", payment_method_id=" + payment_method_id + ", payment_term_id=" + payment_term_id
				+ ", sales_area_id=" + sales_area_id + ", sales_group_id=" + sales_group_id + ", sales_office_id="
				+ sales_office_id + ", shipping_condition_id=" + shipping_condition_id + ", record_status="
				+ record_status + ", date_archived=" + date_archived + ", column21=" + column21 + ", column22="
				+ column22 + ", column23=" + column23 + ", column24=" + column24 + "]";
	}

	
	
	
	
	
}
