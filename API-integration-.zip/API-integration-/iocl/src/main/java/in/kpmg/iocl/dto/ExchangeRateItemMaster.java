package in.kpmg.iocl.dto;

import lombok.Data;

@Data
public class ExchangeRateItemMaster {
    private Integer MANDT;
    private Integer GDATU;
    private Integer FFACT;
    private Integer TFACT;
    private String KURST;
    private String FCURR;
    private String TCURR;
    private String UKURS;

}


