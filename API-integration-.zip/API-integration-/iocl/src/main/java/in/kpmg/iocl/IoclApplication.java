package in.kpmg.iocl;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class IoclApplication {

	public static void main(String[] args) {
		SpringApplication.run(IoclApplication.class, args);
	}

}
